import SwiftUI
import SwiftData
import AVFoundation
import UserNotifications
import Foundation

struct CustomTabBar: View {
    @Binding var selected: Int
    let showTimeline: Bool   // kept for API compat, unused now
    @Environment(\.appMetrics) private var metrics

    var tabs: [(String, String)] {
        [
            ("scope",              "Now"),
            ("calendar",           "Today"),
            ("list.bullet.indent", "Protocols"),
            ("figure.run",         "Physique"),
            ("building.2",         "Hideout"),
            ("antenna.radiowaves.left.and.right", "Signal"),
            ("person",             "You"),
            ("staroflife",         "Recovery"),
        ]
    }

    // Tab bar: compact on iPad — content scales up, chrome stays down.
    var iconSizeActive:   CGFloat { metrics.isIPad ? 17 : 19 }
    var iconSizeInactive: CGFloat { metrics.isIPad ? 15 : 17 }
    var labelSize:        CGFloat { metrics.isIPad ? 9 : 10 }
    var bubbleSize:       CGFloat { metrics.isIPad ? 30 : 36 }
    var iconFrameH:       CGFloat { metrics.isIPad ? 24 : 28 }
    var topPad:           CGFloat { metrics.isIPad ? 5 : 10 }
    var bottomPad:        CGFloat { metrics.isIPad ? 2 : 4 }

    var body: some View {
        VStack(spacing: 0) {
            Rectangle()
                .fill(Color.muted.opacity(0.3))
                .frame(height: 0.5)

            HStack(spacing: 0) {
                ForEach(tabs.indices, id: \.self) { i in
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) { selected = i }
                        #if os(iOS)
                        UIImpactFeedbackGenerator(style: .soft).impactOccurred()
                        #endif
                    }) {
                        VStack(spacing: 4) {
                            ZStack {
                                if selected == i {
                                    Circle()
                                        .fill(Color.violet.opacity(0.10))
                                        .frame(width: bubbleSize, height: bubbleSize)
                                        .blur(radius: 8)
                                }
                                Image(systemName: tabs[i].0)
                                    .font(.system(size: selected == i ? iconSizeActive : iconSizeInactive,
                                                  weight: selected == i ? .medium : .light))
                                    .foregroundStyle(
                                        selected == i
                                        ? AnyShapeStyle(LinearGradient(
                                            colors: [.violetLight, .warm],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing))
                                        : AnyShapeStyle(Color.textMuted.opacity(0.6))
                                    )
                                    .scaleEffect(selected == i ? 1.05 : 1.0)
                                    .animation(.spring(response: 0.3, dampingFraction: 0.7), value: selected)
                            }
                            .frame(width: bubbleSize, height: iconFrameH)

                            Text(tabs[i].1)
                                .font(.mono(labelSize))
                                .tracking(0.5)
                                .foregroundColor(selected == i ? .violetLight : .textMuted.opacity(0.5))
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.top, topPad)
                        .padding(.bottom, bottomPad)
                    }
                }
            }
            .background(Color.bgBase)

            Color.bgBase.frame(height: safeAreaBottom)
        }
    }

    private var safeAreaBottom: CGFloat {
        (UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .first?.windows.first?.safeAreaInsets.bottom) ?? 0
    }
}

// MARK: - SHARED UI HELPERS

// Custom sheet drag handle — replaces iOS default white pill
struct SheetHandle: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(
                LinearGradient(colors: [.violet.opacity(0.5), .warm.opacity(0.3)],
                               startPoint: .leading, endPoint: .trailing)
            )
            .frame(width: 36, height: 3)
            .padding(.top, 12)
            .padding(.bottom, 4)
    }
}

func inputField(_ label: String, placeholder: String, text: Binding<String>) -> some View {
    VStack(alignment: .leading, spacing: 8) {
        MonoLabel(text: label)
        TextField("", text: text, prompt: Text(placeholder).foregroundColor(.textMuted))
            .font(.sora(15)).foregroundColor(.textPrimary)
            .padding(14).background(Color.surface).clipShape(RoundedRectangle(cornerRadius: 10))
            .tint(.warm)
    }
}

func editableField(_ label: String, placeholder: String, text: Binding<String>, multiline: Bool = false) -> some View {
    VStack(alignment: .leading, spacing: 8) {
        MonoLabel(text: label)
        if multiline {
            TextField("", text: text, prompt: Text(placeholder).foregroundColor(.textMuted), axis: .vertical)
                .font(.sora(14)).foregroundColor(.textPrimary).lineLimit(3...6)
                .padding(14).background(Color.surface).clipShape(RoundedRectangle(cornerRadius: 10))
                .tint(.warm)
        } else {
            TextField("", text: text, prompt: Text(placeholder).foregroundColor(.textMuted))
                .font(.sora(14)).foregroundColor(.textPrimary)
                .padding(14).background(Color.surface).clipShape(RoundedRectangle(cornerRadius: 10))
                .tint(.warm)
        }
    }
}

func primaryButton(_ label: String, disabled: Bool, action: @escaping () -> Void) -> some View {
    Button(action: action) {
        Text(label)
            .font(.sora(14, weight: .semibold))
            .foregroundColor(disabled ? .textMuted : .bgBase)
            .tracking(1.8)
            .frame(maxWidth: .infinity).frame(height: 50)
            .background(
                Group {
                    if disabled {
                        Color.surface2
                    } else {
                        LinearGradient(
                            colors: [.violetLight, .violet],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    }
                }
            )
            .clipShape(RoundedRectangle(cornerRadius: 12))
            .shadow(color: disabled ? .clear : Color.violet.opacity(0.25), radius: 12, x: 0, y: 6)
    }
    .disabled(disabled)
}

func segmentControl(_ options: [String], selected: Binding<Int>) -> some View {
    HStack(spacing: 0) {
        ForEach(options.indices, id: \.self) { i in
            Button(action: { selected.wrappedValue = i }) {
                Text(options[i].uppercased())
                    .font(.mono(10, weight: selected.wrappedValue == i ? .medium : .light))
                    .tracking(0.8)
                    .foregroundColor(selected.wrappedValue == i ? .textPrimary : .textMuted.opacity(0.6))
                    .frame(maxWidth: .infinity).padding(.vertical, 9)
                    .background(
                        selected.wrappedValue == i
                            ? Color.surface.opacity(0.9)
                            : Color.clear
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 9))
            }
        }
    }
    .padding(3).background(Color.surface2).clipShape(RoundedRectangle(cornerRadius: 12))
    .overlay(
        RoundedRectangle(cornerRadius: 12)
            .strokeBorder(Color.white.opacity(0.04), lineWidth: 0.5)
    )
}

func emptyState(icon: String, title: String, subtitle: String) -> some View {
    CardView {
        VStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 28)).foregroundColor(.violetDim)
            Text(title).font(.sora(15, weight: .medium)).foregroundColor(.textSecond)
            Text(subtitle).font(.sora(13, weight: .light)).foregroundColor(.textMuted)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 16)
    }
    .padding(.horizontal, 24)  // free function — cannot read @Environment; acceptable fixed value
}


// MARK: - SEED: WEEK 1 HIDEOUT SHIFTS (May 13–17, 2026)
// Seeds the five days of the solo experiment's first week.
// Only called when hideoutShifts.isEmpty — fresh install or data wipe.
// Source: BRICE_OPERATOR_PRODUCT_BRIEF.md, Section 3 — 30-Day Solo Experiment.
//
// Key signal from Week 1:
//   - Every day beat prior week except Thu (Jimmy cold brew $144.45 inflated prior Thu to $549)
//   - $17.29 avg ticket — solo model running ABOVE the $16.72 historical staffed baseline
//   - Stress score 2/10 across the week. The system is working.
//   - Week total: $2,438.77 · 141 tx · $487.75/day avg → between Survival and Stability bands

func seedWeek1Shifts(context: ModelContext) {
    let cal = Calendar.current
    let experimentStart = cal.date(from: DateComponents(year: 2026, month: 5, day: 13)) ?? Date()

    struct ShiftSeed {
        let dayOffset: Int        // days from May 13
        let revenue: Double
        let txCount: Int
        let stressScore: Int
        let notes: String
        let sourceNotes: String
    }

    let seeds: [ShiftSeed] = [
        ShiftSeed(
            dayOffset: 0,   // May 13 — Day 1
            revenue: 419.00,
            txCount: 28,
            stressScore: 2,
            notes: "Day 1. Zero staff. Clean execution. Proved solo model viable. Stress 2/10 — smooth and easy. Watermarc prospective renters stopped in before touring.",
            sourceNotes: "Watermarc referral: 2 prospective renters visited pre-tour — confirmed Watermarc relationship is real and warm."
        ),
        ShiftSeed(
            dayOffset: 1,   // May 14 — Day 2
            revenue: 398.00,
            txCount: 22,
            stressScore: 2,
            notes: "Apples-to-apples this beats the prior Thursday. Prior week Thu was $549 but included Jimmy cold brew order ($144.45) — that inflated it. Strip Jimmy and prior Thu was ~$405. This is a real improvement.",
            sourceNotes: ""
        ),
        ShiftSeed(
            dayOffset: 2,   // May 15 — Day 3
            revenue: 648.00,
            txCount: 44,
            stressScore: 3,
            notes: "Best day of the week. High volume. Above Comfort band ($650 threshold). Prior Fri was $436 — this is +48.6%. Volume day: 44 tx. Showed solo model can handle a full Fri push.",
            sourceNotes: ""
        ),
        ShiftSeed(
            dayOffset: 3,   // May 16 — Day 4
            revenue: 556.00,
            txCount: 27,
            stressScore: 2,
            notes: "Highest avg ticket of the week ($20.59). Group orders. Zero comps. Prior Sat was $516 — +7.8%. High ticket, lower volume — cleaner nervous-system day than Friday.",
            sourceNotes: ""
        ),
        ShiftSeed(
            dayOffset: 4,   // May 17 — Day 5
            revenue: 417.77,
            txCount: 20,
            stressScore: 2,
            notes: "Strong avg ticket ($20.89 — highest of the week). Clean execution. Prior Sun was $322 — +29.7%. Sunday extension to 5PM (Week 2 experiment) starts next week.",
            sourceNotes: ""
        ),
    ]

    for seed in seeds {
        guard let shiftDate = cal.date(byAdding: .day, value: seed.dayOffset, to: experimentStart) else { continue }
        let log = HideoutShiftLog()
        log.date = shiftDate
        log.dateOverride = shiftDate
        log.grossRevenue = seed.revenue
        log.transactionCount = seed.txCount
        log.stressScore = seed.stressScore
        log.usedStaff = false
        log.notes = seed.notes
        log.sourceNotes = seed.sourceNotes
        log.experimentDay = seed.dayOffset + 1
        // Behavioral toggles — not tracked for Week 1 retroactively
        log.usedScriptedUpsell = false
        log.recognizedRegular = false
        log.anchorPhraseUsed = false
        context.insert(log)
    }
}

// MARK: - SEED: PARTNER ACCOUNTS
// Seeds Jimmy (active, episodic) + 5 pipeline prospects from the strategic brief priority list.
// Only runs when partnerAccounts.isEmpty — fresh install or data wipe.

func seedDefaultPartnerAccounts(context: ModelContext) {
    // Jimmy — the proof of concept
    let jimmy = PartnerAccount(name: "Jimmy Holmquist", status: .active)
    jimmy.contactPerson = "Jimmy"
    jimmy.frequency = .episodic
    jimmy.isPickup = true
    jimmy.primarySKU = "Cold Brew — 3 gallons"
    jimmy.estimatedRevenue = 144.45
    jimmy.activatedDate = Calendar.current.date(from: DateComponents(year: 2026, month: 5, day: 7))
    jimmy.lastOrderDate  = Calendar.current.date(from: DateComponents(year: 2026, month: 5, day: 7))
    jimmy.notes = "Invoice 10045. Monthly trail events. Former running partner. Event partner archetype — proves the model. Episodic, not weekly recurring. Pickup only — he collects before events."
    context.insert(jimmy)

    // Pipeline prospects from brief priority order
    struct ProspectSeed {
        let name: String; let contact: String
        let freq: PartnerAccountFrequency; let sku: String; let rev: Double
    }
    let prospects: [ProspectSeed] = [
        ProspectSeed(name: "A Better You — Style Creations", contact: "Salon staff",    freq: .weekly,   sku: "Coffee / matcha daily supply",        rev: 45.0),
        ProspectSeed(name: "SkyView 22 — concierge",         contact: "Concierge",      freq: .weekly,   sku: "Cold Brew 1 gal + batch coffee",       rev: 60.0),
        ProspectSeed(name: "Expansive Biscayne",              contact: "Office manager", freq: .weekly,   sku: "Cold Brew 2–3 gal weekly",             rev: 90.0),
        ProspectSeed(name: "Watermarc leasing office",        contact: "Leasing",        freq: .monthly,  sku: "Office Fuel 15 bundle",                rev: 240.0),
        ProspectSeed(name: "Aria on the Bay",                 contact: "Concierge",      freq: .episodic, sku: "Pastry box + coffee drop",             rev: 80.0),
    ]
    for s in prospects {
        let p = PartnerAccount(name: s.name, status: .prospect)
        p.contactPerson = s.contact
        p.frequency = s.freq
        p.primarySKU = s.sku
        p.estimatedRevenue = s.rev
        p.isPickup = true
        context.insert(p)
    }
    print("INCREMENTS: seeded partner accounts (Jimmy active + \(prospects.count) prospects)")
}



// MARK: - Conduct filter (BRICE_OS — weekly audit habit + maintenance)

enum ConductFilterSeed {
    static let title = "Conduct audit"
    static let cue = "Monday 8:00 AM or Sunday 7:00 PM"
    static let minimumScope = "15 min — one product audit + name one deletion"
    static let auditNotes = """
    Weekly audit:
    • One product: no lesson-voice, no empty slots, defer scope
    • Business / coaching / relationships: one line each
    • Name one deletion for next week
    Delete filter before ship: competence visible? restraint? conduct clear without this line?
    Mac: FORM-iOS/docs/BRICE_OS/CONDUCT_FILTER.md
    """
}

enum ComputerMaintenanceSeed {
    static let hygieneTitle = "Computer hygiene — Mac"
    static let chatTitle = "Telegram + WhatsApp — auto-download"
    static let hygieneNotes = """
    30 min max. Quit Telegram, WhatsApp, Messages first.

    Telegram: Settings → Data and Storage → Auto-Download → Photos/Videos OFF (Wi‑Fi only at most). Use Clear Cache monthly.
    WhatsApp: Settings → Storage → manage; disable auto-download for photos, audio, video.
    Messages: System Settings → General → Storage → Messages → delete large attachments.
    Or run ~/Documents/clear-messages-attachments.sh in Terminal (needs Full Disk Access for Terminal).

    Dev: Xcode → Platforms → delete unused iOS runtimes; simulators → delete unavailable.
    Caches: Spotify, Adobe media cache, Cursor state.vscdb if it grows past ~5 GB.

    Media only — never delete Telegram postbox DB or WhatsApp ChatStorage.sqlite.
    """
    static let chatNotes = """
    Verify auto-download is still off in both apps:
    Telegram → Data and Storage → Auto-Download.
    WhatsApp → Settings → Storage and data → Media auto-download → No Media.
    """
}

enum HideoutAppLaunchSeed {
    static let items: [(title: String, notes: String)] = [
        ("Hideout · SkyView lobby QR", """
        Physical: card stand in SkyView 22 lobby (ground floor near mail).
        QR URL: https://hideoutmiami.com/app?source=skyview
        App shows: "Same building · patio in 2 minutes."
        Success metric: ask 5 SkyView tenants if they scanned — log in Friday WRC.
        """),
        ("Hideout · Watermarc leave-behind", """
        Physical: 10 cards for concierge tours — hand to prospects at tour end.
        QR URL: https://hideoutmiami.com/app?source=watermarc
        App shows: "2-minute walk · terrace pickup."
        Pair with: one Instagram story when card stock is placed (not before).
        """),
        ("Hideout · Salon counter stand", """
        Physical: small stand at A Better You — staff one-liner: "Hideout is two minutes, app for reorder."
        QR URL: https://hideoutmiami.com/app?source=neighbor
        No discount. No streak. Relationship compression only.
        """),
        ("Hideout · Sunday exit card", """
        Physical: printed card at Sunday Morning checkout — weekday hours + app QR.
        QR URL: https://hideoutmiami.com/app?source=weekday
        Opens Today (weekday pickup) — NOT ?source=village (that opens Sunday tab).
        Bridges Sunday crowd to Wed–Fri cafe rhythm. One caramel element on card design.
        """),
        ("Hideout · Office breakfast trial", """
        Target: Expansive Miami or one SkyView tenant office (8 persons min).
        Product: Office Breakfast Package · $16/person · Egg Toast included.
        In app: Catering → Within 2 blocks → Office breakfast (or B2B standing after trial).
        Log outcome in Hideout tab partnership sprint when converted to weekly.
        """),
        ("Hideout · Jimmy B2B end-to-end", """
        Admin iPad: B2B accounts → Jimmy template (3 gal Original Cold Brew).
        Customer device: set name "Jimmy" → Catering tab shows standing order widget.
        Tap Confirm standing order → 48hr lead pickup → Square sandbox payment.
        Ref: Documents/HideoutApp/HIDEOUT_EXECUTION_CHECKLIST.md
        """),
        ("Hideout · App Store privacy URL", """
        Upload docs/HIDEOUT_PRIVACY_POLICY.html to hideoutmiami.com/privacy
        Paste URL in App Store Connect → App Privacy → Privacy Policy URL.
        Also link from app Account tab if not already live.
        """),
        ("Hideout · Universal Links (AASA)", """
        Upload docs/apple-app-site-association to:
        https://hideoutmiami.com/.well-known/apple-app-site-association
        (no file extension, application/json, no redirect)
        Paths: /app*, /order*, /catering*
        Verify: developer.apple.com → App Search Validation Tool
        """),
        ("Hideout · Apple Pay portal", """
        Follow Documents/HideoutApp/docs/APPLE_PAY_SETUP.md step by step:
        1. Apple Developer → Merchant ID
        2. Payment Processing Certificate → upload to Square Dashboard
        3. Entitlements already in HideoutApp.entitlements
        4. Test on physical device with sandbox card
        """),
        ("Hideout · Production payment smoke", """
        Before TestFlight external: one real menu order on production Square.
        Amount: smallest item + tip optional. Refund immediately in Square Dashboard.
        Confirm: order appears in Square Orders, confirmation in app, lastOrder persists after relaunch.
        Bump CURRENT_PROJECT_VERSION in Xcode before upload.
        """),
        ("Hideout · 5 regulars smoke test", """
        Ask 5 known regulars (not staff): install TestFlight → reorder last order → configure modifier item → closed cafe pickup copy → catering 48hr lead.
        Note friction in Hideout tab audit ledger. Fix only blockers — no feature creep.
        """),
        ("Hideout · Friday WRC review", """
        Weekly Revenue Composition card on Hideout tab — fill walk-in, Watermarc, concierge, partnership, Sunday tail.
        Target: 5 neighborhood-attributed visits/week for 2 weeks (Mode B experiment).
        Target: 2 recurring B2B accounts beyond Jimmy within 60 days (Mode C).
        """),
    ]
}

func seedHideoutAppLaunchMaintenance(context: ModelContext, maintenance: [MaintenanceItem]) {
    let titles = Set(maintenance.map(\.title))
    for item in HideoutAppLaunchSeed.items where !titles.contains(item.title) {
        context.insert(MaintenanceItem(
            title: item.title,
            system: .operations,
            intervalDays: 0,
            notes: item.notes
        ))
    }
}

func seedMissingConductFilterItems(context: ModelContext, maintenance: [MaintenanceItem], habits: [Habit]) {
    let maintTitles = Set(maintenance.map(\.title))
    if !maintTitles.contains(ConductFilterSeed.title) {
        context.insert(MaintenanceItem(
            title: ConductFilterSeed.title,
            system: .cognition,
            intervalDays: 7,
            notes: ConductFilterSeed.auditNotes
        ))
    }
    if !maintTitles.contains(ComputerMaintenanceSeed.hygieneTitle) {
        context.insert(MaintenanceItem(
            title: ComputerMaintenanceSeed.hygieneTitle,
            system: .operations,
            intervalDays: 30,
            notes: ComputerMaintenanceSeed.hygieneNotes
        ))
    }
    if !maintTitles.contains(ComputerMaintenanceSeed.chatTitle) {
        context.insert(MaintenanceItem(
            title: ComputerMaintenanceSeed.chatTitle,
            system: .operations,
            intervalDays: 90,
            notes: ComputerMaintenanceSeed.chatNotes
        ))
    }
    let habitTitles = Set(habits.map(\.title))
    if !habitTitles.contains(ConductFilterSeed.title) {
        let habit = Habit(
            title: ConductFilterSeed.title,
            system: .cognition,
            frequency: .weekly,
            cue: ConductFilterSeed.cue,
            minimumScope: ConductFilterSeed.minimumScope
        )
        habit.notes = ConductFilterSeed.auditNotes
        context.insert(habit)
    }
}

func seedDefaultMaintenance(context: ModelContext) {
    let defaults: [(String, SystemTag, Int)] = [
        // Environment
        ("Air filter",              .environment,  30),
        ("Water filter",            .environment,  90),
        ("Deep clean — home",       .environment,  14),
        ("Balcony reset — 26th",    .environment,   7),
        ("Terrace deep clean",      .environment,  14),
        // Personal care
        ("Derma roller — replace",  .health,       90),
        ("Razor blade — replace",   .health,       14),
        ("Toothbrush head",         .health,       90),
        ("Dermatologist check",     .health,       365),
        ("Dental cleaning",         .health,       180),
        ("Eye exam",                .health,       365),
        ("Blood panel — annual",    .health,       365),
        ("25-OH Vitamin D test",    .health,       180),
        ("Testosterone panel",      .health,       180),
        // Operations
        ("Weekly reset",            .operations,    7),
        (ConductFilterSeed.title,   .cognition,      7),
        ("Financial review",        .operations,    7),
        ("Espresso machine deep clean", .operations, 7),
        ("Grinder calibration",     .operations,   14),
        ("App subscription audit",  .operations,   90),
        (ComputerMaintenanceSeed.hygieneTitle, .operations, 30),
        (ComputerMaintenanceSeed.chatTitle,      .operations, 90),
    ]
    for (title, system, interval) in defaults {
        let notes: String
        switch title {
        case ConductFilterSeed.title: notes = ConductFilterSeed.auditNotes
        case ComputerMaintenanceSeed.hygieneTitle: notes = ComputerMaintenanceSeed.hygieneNotes
        case ComputerMaintenanceSeed.chatTitle: notes = ComputerMaintenanceSeed.chatNotes
        default: notes = ""
        }
        context.insert(MaintenanceItem(title: title, system: system, intervalDays: interval, notes: notes))
    }
}

// MARK: - DAILY RESET — clears isCompleted on recurring actions each new calendar day

func resetDailyActionsIfNeeded(context: ModelContext, profile: OperatorProfile, actions: [Action], sessions: [Session] = []) {
    let cal = Calendar.current
    // Only reset once per calendar day
    if let last = profile.lastResetDate, cal.isDateInToday(last) { return }

    // Determine yesterday's weekday for skip counting (we're resetting FOR yesterday)
    let yesterday = cal.date(byAdding: .day, value: -1, to: Date()) ?? Date()
    let yesterdayWD = cal.component(.weekday, from: yesterday)

    for action in actions {
        guard action.recurrence != .none else { continue }   // one-off actions never reset

        let shouldReset: Bool
        switch action.recurrence {
        case .daily:
            shouldReset = true
        case .weekdays:
            shouldReset = yesterdayWD >= 2 && yesterdayWD <= 6
        case .weekends:
            shouldReset = yesterdayWD == 1 || yesterdayWD == 7
        case .weekly:
            if let ca = action.completedAt {
                let days = cal.dateComponents([.day], from: ca, to: Date()).day ?? 0
                shouldReset = days >= 7
            } else {
                let daysSinceCreated = cal.dateComponents([.day], from: action.createdAt, to: Date()).day ?? 0
                shouldReset = daysSinceCreated >= 7
            }
        case .none:
            shouldReset = false
        }

        if shouldReset {
            if !action.isCompleted { action.skipCount += 1 }
            action.isCompleted = false
            action.completedAt = nil
        }
    }

    // Session reset — parallel logic to actions
    // Blank (no log, no skip) = unknown miss → increment skipCount
    // Intentional skip (skipDates recorded) = deliberate signal → don't double-count
    for session in sessions {
        guard session.recurrence != .none, session.isActive else { continue }

        let wasActiveYesterday: Bool
        switch session.recurrence {
        case .daily:   wasActiveYesterday = true
        case .weekdays: wasActiveYesterday = yesterdayWD >= 2 && yesterdayWD <= 6
        case .weekends: wasActiveYesterday = yesterdayWD == 1 || yesterdayWD == 7
        case .weekly:
            let days = cal.dateComponents([.day], from: session.lastCompleted ?? session.createdAt, to: Date()).day ?? 0
            wasActiveYesterday = days >= 7
        case .none: wasActiveYesterday = false
        }

        guard wasActiveYesterday else { continue }

        let completedYesterday = cal.isDateInYesterday(session.lastCompleted ?? .distantPast)
        let skippedYesterday = cal.isDateInYesterday(session.skipDates.last ?? .distantPast)

        if !completedYesterday && !skippedYesterday {
            // Blank — unknown non-completion. Counts as friction.
            session.skipCount += 1
        }
        // Note: intentional skips (skippedYesterday) are already recorded in skipDates.
        // They don't increment skipCount — that's reserved for unlogged misses.
    }

    profile.lastResetDate = Date()
}

// MARK: - SEED DATA

// PRESCRIBED WEEK SCHEDULE (Jul 2026):
// EVERY DAY:  5:00 Wake · no phone · hydrate · creatine · AM stack (Physique) · fasted cardio
//             Mon/Fri: Rod Panorama 6:15 AM (coaching) — compress/skip AM cardio
//             ~5:45 Cold shower · ~6:05 Protein · leave ~6:30 Hideout · 21:15 sleep target
// HIDEOUT:    6:30 arrive + prep (terrace + plants) → 7:00 slow open → 7:30 Priorities → 12:00 Protein + outside
// BASE:       8:00 Mon: Close loop · 8:15 Messages · 8:30 Reset one area
// WEEKLY:     Sun 14:00 Read long · Sun 15:00 Inbox physical · Mon 8:00 Close loop

// Safe missing-action seeder — never duplicates, never wipes existing data.
func seedMissingCoreActions(context: ModelContext, existing: [Action]) {
    let have = Set(existing.map { $0.title })
    let want: Set<String> = [
        "No social · no news — first hour", "Hydrate", "Creatine",
        "Morning grooming", "Cardio — bike or elliptical", "Protein — first meal",
        "Supplements — midday", "Supplements — dinner", "Magnesium glycinate",
        "Pre-lift mobility — 5 min", "Strength training — gym", "Post-workout protein",
        "PM oral care", "No screens — final hour", "Minoxidil", "Sleep by 9:30PM",
        "Stage tomorrow", "Scalp massage — 4 min",
        "Collagen + vitamin C", "Derma roller — Wednesday", "Derma roller — Sunday",
        "Review priorities", "Journal — 3 sentences",
        "Content block \u{2014} Monday",
        "Rod — Panorama · Monday",
        "Rod — Panorama · Friday",
    ]
    let missing = want.subtracting(have)
    guard !missing.isEmpty else { return }
    print("INCREMENTS: seeding missing actions:", missing.sorted().joined(separator: ", "))
    seedDefaultActions(context: context, onlyTitles: missing)
}

func seedMissingSessions(context: ModelContext, existing: [Session]) {
    let have = Set(existing.map { $0.title })
    let want: Set<String> = ["Morning Protocol", "Evening Shutdown", "Whole Human Reset",
                             "Shutdown Preservation", "Pre-Lift Mobility", "PM Oral Care", "Weekly Reset"]
    let missing = want.subtracting(have)
    guard !missing.isEmpty else { return }
    seedDefaultSessions(context: context, onlyTitles: missing)
}

/// Removes duplicate protocol rows (same title) — common after CloudKit partial sync.
func dedupeSessionsByTitle(context: ModelContext, sessions: [Session]) {
    var keeperByTitle: [String: Session] = [:]
    var toDelete: [Session] = []
    for session in sessions {
        if let keeper = keeperByTitle[session.title] {
            let keepSession = keeper.steps.count >= session.steps.count ? keeper : session
            let dropSession = keepSession === keeper ? session : keeper
            keeperByTitle[session.title] = keepSession
            toDelete.append(dropSession)
        } else {
            keeperByTitle[session.title] = session
        }
    }
    guard !toDelete.isEmpty else { return }
    print("INCREMENTS: removing \(toDelete.count) duplicate protocol(s)")
    for session in toDelete { context.delete(session) }
    try? context.save()
}

/// Removes duplicate action rows (same title) — common after CloudKit partial sync.
/// Keeps the action with the most completion history; deletes the other.
func dedupeActionsByTitle(context: ModelContext, actions: [Action]) {
    var keeperByTitle: [String: Action] = [:]
    var toDelete: [Action] = []
    for action in actions {
        if let keeper = keeperByTitle[action.title] {
            // Prefer the one with more completion history
            let keepAction = keeper.completionDates.count >= action.completionDates.count ? keeper : action
            let dropAction = keepAction === keeper ? action : keeper
            keeperByTitle[action.title] = keepAction
            toDelete.append(dropAction)
        } else {
            keeperByTitle[action.title] = action
        }
    }
    guard !toDelete.isEmpty else { return }
    print("INCREMENTS: removing \(toDelete.count) duplicate action(s)")
    for action in toDelete { context.delete(action) }
    try? context.save()
}

/// One shift per calendar day — keeps the richer record when duplicates exist (re-log + seed overlap).
func hideoutShiftCompleteness(_ shift: HideoutShiftLog) -> Int {
    var score = 0
    if shift.grossRevenue > 0 { score += 2 }
    if shift.transactionCount > 0 { score += 1 }
    if shift.stressScore > 0 { score += 1 }
    if !shift.notes.isEmpty { score += 2 }
    if !shift.sourceNotes.isEmpty { score += 1 }
    if shift.repeatCustomerCount + shift.newCustomerCount > 0 { score += 1 }
    if shift.peakBurstUpdated > 0 { score += 1 }
    if shift.usedScriptedUpsell || shift.recognizedRegular || shift.anchorPhraseUsed { score += 1 }
    return score
}

func dedupeHideoutShiftsByDay(context: ModelContext, shifts: [HideoutShiftLog]) {
    let cal = Calendar.current
    var keeperByDay: [Date: HideoutShiftLog] = [:]
    var toDelete: [HideoutShiftLog] = []

    for shift in shifts {
        let day = cal.startOfDay(for: shift.logDate)
        if let keeper = keeperByDay[day] {
            let keepShift = hideoutShiftCompleteness(keeper) >= hideoutShiftCompleteness(shift) ? keeper : shift
            let dropShift = keepShift === keeper ? shift : keeper
            keeperByDay[day] = keepShift
            toDelete.append(dropShift)
        } else {
            keeperByDay[day] = shift
        }
    }

    guard !toDelete.isEmpty else { return }
    print("INCREMENTS: removing \(toDelete.count) duplicate Hideout shift(s)")
    for shift in toDelete { context.delete(shift) }
    try? context.save()
}

/// Removes Today stack items retired May 2026 — pre-shift behaviors, deep work block, split terrace/plant.
enum PrescribedStackRetirement {
    static let retiredActionTitles: Set<String> = [
        "Pre-shift: load the 4 behaviors",
        "Deep work block — 90 min",
        "Plant check — water + prune",
        "Terrace audit — opening",
        "Pre-fuel — small",
        "Pre-lift warmup — 20 min",
        "Protein before sleep",
        "Red light — 10 min",
        "Gratitude — 3 items",
        "Intentional learning — 15 min",
        "Epsom salt soak — foot",
        "Learn 3 regulars",
        "Coffee craft — one technique",
        "Menu engineering — weekly",
        "Progress photos — Sunday",
        "Contrast shower — post-gym",
        "Legs up the wall — 5 min",
        "Nasal breathing — cardio check",
        "Body scan — 30 sec",
        "Nail care",
        "Ear cleaning",
        "Sleep position — lateral",
        "20-20-20 — Hideout screens",
        "Compliment or acknowledge",
        "Condo 26th floor — balcony reset",
    ]

    static let retiredSessionTitles: Set<String> = [
        "Deep Work Block",
        "Solo Operator Protocol",
        "Pre-Lift Warmup",
    ]

    /// Catches legacy titles and CloudKit variants not in the exact retire set.
    static func isRetiredActionTitle(_ title: String) -> Bool {
        if retiredActionTitles.contains(title) { return true }
        let t = title.lowercased()
        if t.hasPrefix("pre-shift") { return true }
        if t.hasPrefix("plant check") { return true }
        if t.contains("terrace audit") { return true }
        if t.contains("pre-lift warmup") { return true }
        if t.contains("protein before sleep") { return true }
        if t.contains("deep work block") { return true }
        if t.hasPrefix("pre-fuel") { return true }
        return false
    }

    static func isRetiredSessionTitle(_ title: String) -> Bool {
        retiredSessionTitles.contains(title)
    }

    /// Dedupe, retire legacy clutter, patch sessions, seed any missing core rows.
    /// Fetches fresh from the store so CloudKit imports after launch are cleaned too.
    static func normalize(context: ModelContext) {
        let actions = (try? context.fetch(FetchDescriptor<Action>())) ?? []
        let sessions = (try? context.fetch(FetchDescriptor<Session>())) ?? []

        dedupeActionsByTitle(context: context, actions: actions)
        dedupeSessionsByTitle(context: context, sessions: sessions)

        let actionsAfterDedupe = (try? context.fetch(FetchDescriptor<Action>())) ?? []
        let sessionsAfterDedupe = (try? context.fetch(FetchDescriptor<Session>())) ?? []

        var changed = false
        for action in actionsAfterDedupe where isRetiredActionTitle(action.title) {
            context.delete(action)
            changed = true
        }
        for session in sessionsAfterDedupe where isRetiredSessionTitle(session.title) {
            context.delete(session)
            changed = true
        }
        if changed { try? context.save() }

        refreshEveningShutdownSession(context: context, sessions: (try? context.fetch(FetchDescriptor<Session>())) ?? [])
        refreshJul2026OperatorSchedule(context: context)

        let remainingActions = (try? context.fetch(FetchDescriptor<Action>())) ?? []
        let remainingSessions = (try? context.fetch(FetchDescriptor<Session>())) ?? []
        seedMissingCoreActions(context: context, existing: remainingActions)
        seedMissingSessions(context: context, existing: remainingSessions)
    }
}

func retirePrescribedStackItems(context: ModelContext, actions: [Action], sessions: [Session]) {
    var changed = false
    for action in actions where PrescribedStackRetirement.isRetiredActionTitle(action.title) {
        context.delete(action)
        changed = true
    }
    for session in sessions where PrescribedStackRetirement.isRetiredSessionTitle(session.title) {
        context.delete(session)
        changed = true
    }
    if changed { try? context.save() }
}

/// Patches Evening Shutdown steps when nutrition doctrine changes (e.g. no pre-sleep protein).
func refreshEveningShutdownSession(context: ModelContext, sessions: [Session]) {
    guard let session = sessions.first(where: { $0.title == "Evening Shutdown" }) else { return }
    let steps = [
        "8:25 — PM oral care: floss → brush → tongue scraper",
        "8:28 — Lights to lamps. Phone to other room.",
        "8:30 — No screens begins",
        "8:35 — Minoxidil (dry scalp, 45 min dry time needed)",
        "8:40 — Magnesium glycinate (400mg)",
        "8:45 — Stage tomorrow: bag packed, outfit set, kitchen staged, app open",
        "8:50 — Read (physical book, 20+ pages)",
        "8:55 — Kitchen closed. Light stomach — protein target hit by final meal.",
        "9:15 — Lights out. Side sleep position.",
    ]
    guard session.steps != steps else { return }
    session.steps = steps
    try? context.save()
}

private let jul2026ScheduleRefreshKey = "increments_schedule_refresh_jul2026_v1"

/// One-time patch: 5:00 wake, Rod Panorama Mon/Fri, growth-era copy. Runs on every normalize until keyed.
func refreshJul2026OperatorSchedule(context: ModelContext) {
    guard !UserDefaults.standard.bool(forKey: jul2026ScheduleRefreshKey) else { return }

    let actions = (try? context.fetch(FetchDescriptor<Action>())) ?? []
    let actionPatches: [(match: String, block: String?, cue: String?, note: String?)] = [
        ("No social · no news — first hour", "5:00", "5:00 wake — open Increments, not Instagram", nil),
        ("Hydrate", "5:02", nil, nil),
        ("Open the blinds", "5:04", nil, nil),
        ("Creatine", "5:06", nil, nil),
        ("Cardio — bike or elliptical", "5:15", nil,
         "STEADY STATE: 35–40 min Zone 2. Skip Mon/Fri mornings — Rod at Panorama 6:15. Optional 20 min only if time before leave."),
        ("Cold exposure — 2 min", "5:45", nil, nil),
        ("Morning grooming", "5:48", nil, nil),
        ("Protein — first meal", "6:05", nil, nil),
        ("Journal — 3 sentences", "6:10", nil, nil),
        ("Morning light exposure", "6:12", nil,
         "Real sunlight when available. On Hideout days, full sun at terrace open (7AM). Civil twilight ~6:00 in summer."),
        ("Sleep by 9:30PM", nil, nil,
         "End of shutdown corridor. 5:00 wake = 6.5 hr ceiling. 9:15–9:30 target."),
        ("Stage tomorrow", nil, nil,
         "Bag packed · outfit set · kitchen staged · app open to Today for 5:00 wake."),
        ("Strength training — gym", "17:30", "5:30 PM — Forge Breechay after Hideout",
         "Forge Breechay ~5:30 PM. Rod Panorama Mon/Fri 6:15 AM is separate — coaching, not your session."),
    ]

    var changed = false
    for patch in actionPatches {
        guard let action = actions.first(where: { $0.title == patch.match }) else { continue }
        if let block = patch.block { action.scheduledBlock = block; changed = true }
        if let cue = patch.cue { action.cue = cue; changed = true }
        if let note = patch.note { action.note = note; changed = true }
    }

    if let session = (try? context.fetch(FetchDescriptor<Session>()))?.first(where: { $0.title == "Morning Protocol" }) {
        let steps = [
            "5:00 — Wake. No phone. Open blinds.",
            "5:02 — Water (500ml) + weigh in (post-bathroom) + Garmin HRV glance",
            "5:06 — Creatine (5g) — skip if on planned pause",
            "5:10 — Core + AM activation (Physique) — then fasted cardio (skip Mon/Fri if Rod 6:15)",
            "5:45 — Cold finish (last 2 min of shower cold)",
            "5:48 — Grooming corridor",
            "6:05 — Protein first meal (30g minimum)",
            "6:10 — Journal (3 sentences)",
            "Mon/Fri 6:15 — Rod · Panorama (coaching)",
            "Leave ~6:30 on Hideout days"
        ]
        if session.steps != steps {
            session.steps = steps
            session.cue = "5:00 AM wake target"
            changed = true
        }
    }

    if changed { try? context.save() }

    seedDefaultActions(context: context, onlyTitles: [
        "Rod — Panorama · Monday",
        "Rod — Panorama · Friday",
    ])

    UserDefaults.standard.set(true, forKey: jul2026ScheduleRefreshKey)
}

func seedDefaultActions(context: ModelContext, onlyTitles: Set<String>? = nil) {
    // (title, system, points, note, cue, recurrence, scheduledBlock, dayTypeRaw)
    // Format: (title, system, points, note, cue, recurrence, scheduledBlock, dayTypeRaw, priorityTierRaw, mechanismNote)
    // note = short execution cue (1-2 lines, always visible)
    // mechanismNote = causal mechanism (expandable, why it works this way)
    let defaults: [(String, SystemTag, Int, String?, String, RecurrenceType, String?, String?, String?, String?)] = [

        // ── MORNING ANCHOR — every day (5:00 wake target) ─────────────────────
        ("No social · no news — first hour", .cognition, 10,
         "Increments is the exception. The rule is no consumption — no social feeds, no news, no messages. The first hour is for execution, not input. News optimized for anxiety is not neutral input.",
         "5:00 wake — open Increments, not Instagram", .daily, "5:00", nil, "anchor", nil),

        ("Hydrate",                    .health,        5,
         "500ml before anything. 3L target today.\\nWhile filling: step on scale (post-bathroom, no clothes), glance at Garmin body battery.",
         "Right after wake",                       .daily,   "5:02",  nil, "anchor", nil),

        ("Open the blinds",            .environment,   5,
         "Light signal. Pre-dawn — open anyway. The act cues wakefulness before sunrise.",
         "Walking to kitchen or balcony",          .daily,   "5:04",  nil, nil, nil),

        ("Creatine",                   .health,        5,
         "5g with water when taking it. Week off is fine — see mechanism note.",
         "With morning water",                     .daily,   "5:06",  nil, "anchor", "Saturation protocol — 5g/day when active. Initial scale jump is mostly intracellular water (1–3 lb), not fat. A brief pause for scale clarity on a cut is reasonable; resume when ready. Do NOT take with zinc (dinner) — absorption competition."),

        ("Cardio — bike or elliptical", .health,      15,
         "STEADY STATE (default): 35–40 min Zone 2, 130–145 BPM. Fasted default — no pre-cardio carbs.\nOverride: half banana only if body battery <30 or HRV suppressed.\nSkip Mon/Fri mornings — Rod at Panorama 6:15. Optional 20 min only if time before leave.",
         "After core + activation (Physique) — aim done by ~6:10 on Hideout days", .daily, "5:15", nil, nil, nil),

        ("Cold exposure — 2 min",      .health,       10,
         "Last 2 minutes of shower cold. Not the whole shower — just the finish.",
         "End of shower",                          .daily,   "5:45",  nil, nil, nil),

        ("Morning grooming",           .health,       10,
         "Grooming corridor — 14 min. See Whole Human Reset session for full sequence.",
         "After shower — corridor start",      .daily,   "5:48",  nil, "anchor", nil),

        ("Protein — first meal",       .health,        5,
         "30g minimum. Eggs + chicken or pumpkin seed shake. Pre-commute. Eat before you leave.",
         "First meal — before leaving for hideout",  .daily,   "6:05",  nil, "anchor", nil),

        ("Supplements — midday",       .health,       10,
         "Take with first fat-containing meal (9:30 AM at Hideout, ~9:00 AM at home):\n• Vitamin D3: 5,000 IU — Miami sun + consistent SPF = still likely deficient. Test 25-OH-D biannually, target 50–70 ng/mL.\n• K2 (MK-7): 100mcg — routes D3-driven calcium to bones, not arteries. D3 without K2 long-term is a cardiovascular risk.\n• Vitamin C: 500mg — or rely on breakfast strawberries (~85mg/cup). Supports collagen synthesis, immune function, cortisol clearance.",
         "With first fat meal — 9:30 AM",           .daily,   "9:30",  nil, nil, nil),

        ("Supplements — dinner",        .health,       10,
         "Take with final meal (7:00–7:30 PM):\n• Omega-3: 2–3g EPA+DHA combined. Triglyceride form, refrigerate. Anti-inflammatory — directly counters the inflammatory load of cut + daily training + foot injury recovery. Reduces DOMS, supports cognitive performance.\n• Zinc: 15–25mg picolinate or bisglycinate. NOT with creatine (AM) — they compete for absorption. Depleted rapidly by sweat — active outdoor shift + daily cardio = significant loss. Suppresses testosterone and wound healing when deficient.\n• Ashwagandha KSM-66: 300–600mg. Not generic ashwagandha — KSM-66 is the studied extract. Reduces cortisol, improves VO2 max, supports testosterone under chronic stress load. Takes 4–8 weeks. Not in the morning — causes drowsiness initially.",
         "With final meal — after gym",             .daily,  "19:30",  nil, nil, nil),

        ("Journal — 3 sentences",      .cognition,    10,
         "What happened. What I noticed. What's next.",
         "After protein — before leaving",         .daily, "6:10", nil, nil, nil),

        ("Morning light exposure",     .health,        5,
         "Real sunlight when available. On Hideout days, full sun at terrace open (7AM). Civil twilight ~6:00 in summer.",
         "Post-cardio or commute — natural light when available",  .daily,   "6:12",  nil, nil, nil),

        ("Rod — Panorama · Monday",    .participation, 15,
         "Coaching session · Panorama 6:15. Leave by 6:10. Compress AM stack — core + activation only before.",
         "Panorama · 6:15 AM",                     .weekly,  "6:15", nil, "anchor", nil),

        ("Rod — Panorama · Friday",    .participation, 15,
         "Coaching session · Panorama 6:15. Then Hideout prep — arrive terrace by 6:30.",
         "Panorama · 6:15 AM",                     .weekly,  "6:15", nil, "anchor", nil),

                // ── HIDEOUT DAYS — Wed–Fri 7AM–5PM, Sat–Sun 7AM–3PM ─────────────────────────
        ("Review priorities",          .operations,   10,
         "5 min. What are the 3 things? Write them down before anything else.",
         "7:30 — after the door opens and the first rush settles. You arrived at 6:30, the prep is done, now orient.",
         .daily,   "7:30",  "hideout", "anchor", nil),

        ("Protein — second hit",       .health,        5,
         "30g. Noon break.",
         "Noon — hideout midday break",            .daily,   "12:00", "hideout", nil, nil),

        ("Outside — 15 min",           .participation, 5,
         "Walk. Balcony if after 5pm and heat's tolerable with a fan.",
         "After noon protein on hideout days",     .daily,   "12:15", "hideout", nil, nil),

        // Gym — 5PM fixed anchor, building condo gym with Tim
        ("Pre-lift mobility — 5 min",  .health,       5,
         "Optional amplifier — not required if first sets feel good.\nHip flexor 60s/side · T-spine rotation 10/side · ankle circles as needed — tibia ~95%.\nAdd dead hang 30s after long Hideout shifts.",
         "5:25 PM — gym floor, before first working set", .daily, "17:25", nil, "amplifier", nil),

        ("Strength training — gym",    .health,       20,
         "Forge Breechay ~5:30 PM. Rod Panorama Mon/Fri 6:15 AM is separate — coaching, not your session.",
         "5:30 PM — after optional 5-min mobility",
         .daily,   "17:30", nil, "anchor", nil),

        ("Post-workout protein",       .health,        5,
         "30g within 30 min of training. The window matters here more than other meals.",
         "Immediately after gym",                   .daily,   "18:00", nil, "anchor", nil),

        // ── BASE DAYS — Mon–Tue cafe/ops/maintenance ───────────────────────────
        ("Respond to 3 messages",      .operations,    5,
         "Clear the queue. Not all of it — just what needs you.",
         "After morning anchor, at the cafe",      .daily,   "8:15",  "base", nil, nil),

        ("Apartment reset — one area", .environment,  10,
         "Rotate daily: Monday = desk surface · Tuesday = kitchen counter + sink. One area, done completely. Not a sweep — an actual reset. The environment system is the gateway system — disorder here costs every other system.",
         "Monday/Tuesday base morning — pick one area",  .daily,  "8:30",  "base", nil, nil),

        ("Protein — noon, base day",   .health,        5,
         "30g. Eggs, chicken, or pumpkin seed shake. Base days you're home or at a café — easier to execute than hideout. Don't skip because the environment is casual.",
         "Noon — base day, wherever you are",      .daily,   "12:00", "base", nil, nil),

        // ── EVENING ANCHOR — every day ─────────────────────────────────────────
        ("PM oral care",               .health,       10,
         "Floss → brush 2 min → tongue scraper. Sequence is not optional.",
         "Before shutdown — 8:25 PM",               .daily,  "20:25", nil, "anchor", nil),

        ("No screens — final hour",    .health,       10,
         "Lights to lamps. Phone to other room. Not silent — other room.",
         "8:30 PM — start of shutdown corridor",   .daily,   "20:30", nil, "anchor", nil),

        ("Minoxidil",                  .health,       10,
         "Dry scalp only. Crown + top zone. Light spread. Must dry 45 min before pillow.",
         "8:20 PM — 45 min before sleep. If using derma roller tonight, apply within 30 min of rolling.",   .daily,   "20:20", nil, "anchor", nil),

        ("Read before sleep",          .cognition,    15,
         "Physical book. 20+ pages. No Kindle. Your Garmin confirms the REM effect — this is a sleep action as much as a reading action.",
         "After shutdown staging",     .daily,   "20:50", nil, nil, nil),

        ("Sleep by 9:30PM",            .health,       10,
         "End of shutdown corridor. 5:00 wake = 6.5 hr ceiling. 9:15–9:30 target. Every system — fat loss, muscle retention, cortisol, HRV — degrades when this slips. Sleep is not a reward; it is a performance input.",
         "End of shutdown corridor",        .daily,   "21:15", nil, "anchor", nil),

        // ── HIDEOUT PREP — terrace + plants (single pass) ─────────────────────
        ("Terrace + plants — opening prep", .environment, 10,
         "One prep pass at arrival: plants first (dry soil, dead leaves, yellowing), then terrace (chairs, surfaces, debris, signage, music). Not two separate slots.",
         "6:35 — first minutes of Hideout prep window", .daily, "6:35", "hideout", nil, nil),

        // ── HIDEOUT OPERATIONS ────────────────────────────────────────────────
        ("Watermarc relationship touch",     .participation,15,
         "Bring coffee to leasing office. Introduce Hideout. Ask if they'll mention us on tours. Leave cards with concierge. One relationship = potentially dozens of high-value regulars.",
         "First available morning at Hideout",           .weekly,  nil,     "hideout", nil, nil),
        ("One real conversation",      .participation,10,
         "Phone call counts. A real text thread counts. A DM reply doesn't.",
         "Any natural transition in the day",      .daily,   nil,     nil, nil, nil),

        ("Make something",             .participation,15,
         "Write, build, design, cook. Output, not consumption. Anything counts if you made it.",
         "Weekend — any time",                     .weekends, nil,    nil, nil, nil),


                // ── NIZORAL — Tuesday + Saturday ──────────────────────────────────────
        ("Nizoral — Tuesday",          .health,       10,
         "In the shower. Apply ketoconazole shampoo to scalp — not just hair. Gentle massage. Leave 5 min. Rinse well. Condition mids/ends only if dry. Controls scalp inflammation and fungal environment. Adjunct to minoxidil, not a substitute.",
         "Tuesday shower",                         .weekly,  nil,     nil, nil, nil),

        ("Nizoral — Saturday",         .health,       10,
         "Same as Tuesday. Scalp only. 5-minute contact. Rinse. Condition ends if needed.",
         "Saturday shower",                        .weekly,  nil,     nil, nil, nil),

        // ── PAULA'S CHOICE BHA — Friday ───────────────────────────────────────
        ("BHA texture night — Friday", .health,       10,
         "Paula's Choice BHA exfoliant. Correct tool for texture — better than extended cleanser contact time. After PM cleanse, dry face, thin layer, avoid eye area. Moisturize after if needed. Start 1x weekly. DO NOT combine with retinoid actives same night.",
         "Friday night — after PM cleanse",        .weekly,  nil,     nil, nil, nil),

        // ── INACTIVE — rosemary requires jojoba carrier oil not yet purchased ──
        // When jojoba purchased, uncomment:
        // ("Rosemary scalp — Wednesday", .health, 10,
        //  "Mix: 1 tbsp jojoba + 6 drops rosemary essential oil + small castor (70/20/10 approx). NEVER apply pure rosemary directly — concentrated essential oil causes irritation and inflammatory shedding. Section hair, apply few drops, massage 5 min, leave overnight. Wash next morning.",
        //  "Before bed — Wednesday", .weekly, nil, nil, nil),
        // ("Rosemary scalp — Sunday", .health, 10,
        //  "Same as Wednesday. Diluted blend only. Leave overnight if tolerated. Wash Monday morning.",
        //  "Before bed — Sunday", .weekly, nil, nil, nil),

        // PLANNED — full-face retinoid (purchase when capital allows) — now Wed/Sat in rotation
        ("Retinol — Wednesday",  .health, 15,
         "Full-face retinoid only — not eye cream. Cleanse first. Wait 10-20 min until skin fully dry. Pea-sized only. Dot forehead, cheeks, chin. Avoid eyelids, nostril folds, corners of mouth. Moisturize after. No BHA or glycolic same night.",
         "After PM cleanse — Wednesday night", .weekly, nil, nil, nil, nil),
        ("Retinol — Saturday", .health, 15,
         "Same as Wednesday. Cleanse → dry 10-20 min → pea-sized retinoid → moisturize. No exfoliant same night.",
         "After PM cleanse — Saturday night", .weekly, nil, nil, nil, nil),

        // PLANNED — finasteride consult (next capital deployment after 90-day stack run)
        // Crown + top pattern = androgenic thinning. Minoxidil supports growth.
        // Finasteride addresses the driver (DHT). Generic is inexpensive once prescribed.
        // Do not initiate until current owned stack has run consistently for 90 days.

        // PLANNED — hair clinic review (6-month horizon)
        // Re-evaluate prior successful scalp/hairline injectable intervention when resources allow.
        // Defer until core stack has run 6+ months. Not before.

        // ── WEEKLY ─────────────────────────────────────────────────────────────
        ("Read something long",        .cognition,    15,
         "Article, essay, or book chapter. Not a thread, not a summary. On base days (Mon/Tue), this fits naturally post-lunch.",
         "Sunday or base day afternoon",           .weekly,  "14:00", "base", nil, nil),

        ("Inbox zero — physical",      .environment,  10,
         "Mail, packages, receipts. The physical pile.",
         "Sunday afternoon — after reading",       .weekly,  "15:00", nil, nil, nil),

        ("Close one open loop",        .operations,   15,
         "One thing that's been sitting. A reply, a decision, a task. One — not a list.",
         "Monday morning — first thing",           .weekly,  "8:00",  "base", nil, nil),

        // ── SUNLIGHT ON SKIN — at Hideout open ───────────────────────────────
        ("Sunlight — face + arms",     .health,        5,
         "5–10 min direct sun on face and forearms at Hideout open. You're on an outdoor terrace — this is free. Vitamin D synthesis, circadian signal reinforcement, mood. You arrive at 6:30 and you're outdoors during the whole prep window — this is passive during setup. Miami sunrise is ~6:32–7:11 depending on month. Don't wear SPF for this window; apply after.",
         "During 6:30–7:00 prep window — you're already outside on the terrace",  .daily, "6:40", "hideout", "amplifier", nil),

        // ── MAGNESIUM GLYCINATE — nightly ────────────────────────────────────
        ("Magnesium glycinate",        .health,       10,
         "400mg glycinate form with water.",
         "8:40 PM — before Stage tomorrow routine",         .daily,  "20:40", nil, "anchor", nil),

        // ── COLLAGEN + VITAMIN C — pre-lift ──────────────────────────────────
        ("Collagen + vitamin C",       .health,       10,
         "10g collagen peptides + vitamin C source (1 cup strawberries covers it) 30–45 min before lifting.",
         "30–45 min before Forge Breechay — with pre-lift meal",  .daily, "16:45", nil, "amplifier",          "Collagen synthesis in connective tissue peaks specifically when collagen peptides AND vitamin C are co-present during mechanical loading — not before, not after. The 30–60 min pre-exercise window is the evidence-based timing. Strawberries cover the vitamin C requirement. Direct relevance: foot injury tendon repair + protecting connective tissue under daily Forge Breechay volume."),

        // ── WEEKLY DEBRIEF — Sunday ──────────────────────────────────────────
        ("Weekly output review",       .operations,   15,
         "Sunday. 15 min. Answer: What moved this week? What didn't? What's the one structural change that would make next week better? Not a retrospective — a routing correction. Write 3 sentences max. This is the highest-leverage 15 minutes of the week if you actually do it.",
         "Sunday — after Hideout close",            .weekly, "15:30", "hideout", nil, nil),

        // ── MONDAY CONTENT BLOCK — distribution protocol ─────────────────────
        // The one fixed weekly distribution action. 20 min before Hideout opens on base day.
        // Same footage → GBP post + Reels/TikTok + RunCards post + FORM/Forge screen capture.
        // Source: DISTRIBUTION_OPERATING_SYSTEM.md — Monday Block section.
        ("Content block — Monday",     .operations,   15,
         "20 min. Fixed shot list — no decisions at execution. Sequence:\\n1. Hideout: fixed 7-shot sequence (wide patio → entrance → espresso → plate → patio+skyline → coffee on table → seated POV). Film before anything else.\\n2. Edit: cut to 20–30 sec vertical, natural audio only.\\n3. Upload to GBP first (primary channel) → same file to Reels → same to TikTok. No captions beyond 2 lines.\\n4. RunCards: one run card from the database, one city, one post.\\n5. FORM/Forge: one real decision from the training week. Screen recording + one context line.\\nPost and leave. No feed. No browsing. No engagement. Done.",
         "Monday AM — before Hideout prep. Before you open anything else.",
         .weekly, "6:00", "base", "anchor",
         "Fixed protocol beats inspiration. This 20-min block is the entire distribution system for the week across all four ventures. Skipping one week = zero distribution surface contact that week. Over 8 weeks of consistent execution, this produces legible signal data. Without it, there is no data — only noise and guessing."),

        // ══ ORAL HEALTH ═══════════════════════════════════════════════════════
        ("Derma roller — Sunday",      .health,       10,
         "Same as Wednesday. 0.5mm. Clean before use. Apply minoxidil after within 30 min. The Wed/Sun schedule gives 3–4 days between sessions — sufficient healing time for 0.5mm depth.",
         "Sunday night — before minoxidil",          .weekly, nil,     nil, nil, nil),

        ("Caffeine shampoo — Mon/Thu", .health,        5,
         "Alpecin or similar caffeine shampoo. Leave on scalp 2 minutes before rinsing. Caffeine penetrates follicles and counteracts DHT-induced growth inhibition directly at the follicle level — the same mechanism as topical minoxidil but different pathway. Stacks with, not substitutes for, the protocol. On non-Nizoral days.",
         "Monday and Thursday shower",               .weekly, nil,     nil, nil, nil),

        // ══ SKIN — ADVANCED PROTOCOL ══════════════════════════════════════════
        ("Glycolic acid — Tuesday PM", .health,      10,
         "AHA exfoliant, 8–10%. Apply to dry face after PM cleanse. Thin layer, avoid eye area. Targets surface texture, fine lines, and pigmentation. Alternating with BHA Friday gives exfoliation coverage without overlap. Don't combine with retinoids same night.",
         "Tuesday PM — after cleanse, before moisturizer",  .weekly, nil,  nil, nil, nil),

        ("Body SPF — exposed areas",   .health,       10,
         "Arms, back of neck, any exposed skin. SPF 30 minimum. You're on an outdoor terrace Wed–Sun, arriving at 6:30 in direct morning sun. UVA causes cumulative skin aging regardless of burn — and Miami UVI is high year-round. Apply after the sunlight-on-skin window (6:40 passively during prep) — don't block that first 10 min. Spray SPF is fine for body. Reapply at noon if you're still in direct sun.",
         "6:50 AM — after sunlight window, still in prep, before first customer", .daily, "6:50", "hideout", nil, nil),

        // ══ SLEEP HYGIENE — COMPLETE ══════════════════════════════════════════
        ("Room temperature — set",     .environment,   5,
         "65–68°F (18–20°C). Core body temperature must drop ~1–2°F to initiate and maintain sleep. Hot rooms prevent this drop — they reduce deep sleep and REM regardless of how tired you are. Set AC 30 min before sleep. In Miami, running AC at night is not optional if you care about sleep quality. If you wake at 3AM feeling hot, room temp is the culprit.",
         "8:15 PM — before no-screens window",       .daily,  "20:15", nil, nil, nil),

        ("Stage tomorrow",             .environment,  10,
         "4 things, 4 minutes: (1) Gym bag packed and by door — including collagen, pre-lift snack, any supplements. (2) Tomorrow's outfit on the chair. (3) Kitchen staged — creatine + magnesium out, water bottle filled. (4) App open to Today so first action is visible at 5:00. Every decision you eliminate from the morning window is a direct performance upgrade.",
         "8:45 PM — during shutdown",                .daily,  "20:45", nil, "anchor", nil),

        ("Weekly financial check",     .operations,   10,
         "10 min. Not a full review — just: what came in this week, what went out, what's the shift from target, is there a decision needed before next week. For Hideout: is weekly revenue trending toward stability band or above. For personal: any irregular expense requiring adjustment. This is pattern maintenance, not anxiety management. Calm, factual, 10 min.",
         "Monday morning — base day",                .weekly, "9:00",  "base", nil, nil),

        // ══ RELATIONSHIP + PARTICIPATION ══════════════════════════════════════
        ("Scalp massage — 4 min",      .health,        5,
         "Fingertips only — no nails, no palm, no tool. Firm circular pressure, not scratching. Zones in order: temples, crown, occiput (back of skull), sides. 4 full minutes — use a timer once to calibrate what it feels like, then it becomes automatic. Mechanism: mechanical stress on dermal papilla cells triggers gene expression for thicker hair shaft diameter. 24-week study showed statistically significant thickness increase at 4 min/day. Optimal windows: (1) in the shower during conditioner dwell time — warm water and vasodilation amplify blood flow to follicles; (2) immediately after applying minoxidil on treatment nights — massage distributes the solution from drop sites across the zone and increases follicular absorption. Don't do it dry on an irritated or flaking scalp — wet is gentler. Scalp massager tools feel good but reduce feedback; fingertips let you feel tension, tender spots, and areas of poor circulation.",
         "In the shower — during conditioner dwell time",  .daily, nil,  nil, nil, nil),

        ("Send one meaningful message", .participation, 10,
         "One message to one person that requires thought. Not a reaction, not a reply to a notification — an initiated message with actual content. Check in on someone's specific situation. Share something relevant to them specifically. Make a plan. This is relationship maintenance as a repeatable action. It takes 2 minutes. Over time, your network cohesion is the sum of these small acts.",
         "Any natural transition in the day",        .daily,  nil,     nil, nil, nil),

        // ── BODY COMPOSITION TRACKING ═════════════════════════════════════════
        ("Training log — post session", .health,       10,
         "After every Forge Breechay session: log weights for each main movement. Note any week-over-week PR — that number is the competition signal. Memory underestimates actual lifts by ~8–12%. Progressive overload during a cut is what signals muscle retention. 2 minutes per session.",
         "Immediately after Forge Breechay — before shower", .daily, "18:45", nil, "amplifier", nil),

        // ══ NUTRITION — GAPS ══════════════════════════════════════════════════
        ("Electrolytes — midday",      .health,        5,
         "Sodium + potassium + magnesium mid-shift. Options: pinch of sea salt in water bottle, coconut water (has potassium), LMNT or similar packet. With daily Zone 2 cardio + 10-hour active outdoor shift in Miami heat, sweat losses are significant. Signs of electrolyte deficit: afternoon headache, muscle cramps, flat lifts, brain fog by 3PM. This is often what people misidentify as 'low energy.'",
         "Midday at Hideout — 12:30 PM with protein meal", .daily, "12:30", "hideout", nil, nil),

        // ── MEAL RAIL — full day sequence, timing matters for cut adherence ────────────
        // These appear on Today so the full wake→cardio→protein→meals→gym→shutdown arc is visible.
        // Tap to see what, why, and how much. Adherence here determines whether results come from
        // the plan or something else. Logged = data. Unlogged = noise.

        ("Post-cardio protein anchor",  .health,       5,
         "Pumpkin seed protein in oat milk · 2 hard boiled eggs optional.\nShake only. No carbs yet — fat oxidation window still open for ~60–90 min post Zone 2.",
         "Immediately after cardio — before shower",  .daily,  "5:15",  nil, "anchor",
         "Post-exercise protein synthesis peaks within 30 min of training end. Fat oxidation from Zone 2 continues until the first carbohydrate meal — carbs here spike insulin and close the window. Protein (not carbs) is the correct post-cardio-only fuel if fat loss is the target. ~340 kcal · 40g P."),

        ("First solid meal",            .health,       5,
         "1 banana · 100g roasted chicken · 2 hard boiled eggs.\nBanana + chicken + 2 eggs. Same every day.",
         "9:30 AM — first carb of the day",           .daily,  "9:30", nil, "anchor",
         "First carbohydrate of the day. Banana closes the fat oxidation window and opens glycolytic fueling. The consistency eliminates decision cost — same meal, same time, no thinking. ~490 kcal · 55g P."),

        ("Midday protein + greens",     .health,       5,
         "Spinach or arugula · 130g roasted chicken · olive oil · balsamic glaze.\nGreens + chicken + olive oil. No bread at lunch.",
         "1:30 PM — midday meal",                     .daily,  "13:30", nil, nil,
         "Protein distribution across the day matters — spreading intake every 3–4 hrs maximises muscle protein synthesis. Skipping this meal compresses protein into 2 windows and reduces anabolic signal. Olive oil supports fat intake targets on a cut. ~390 kcal · 50g P."),

        ("Pre-lift carb prime",         .health,       10,
         "2 slices Zak sourdough · 1.5 tbsp peanut or almond butter.\nPack it at Hideout, don't decide it at 5PM. Most critical meal of the day for training output.",
         "5:00 PM — 30–45 min before Forge Breechay", .daily,  "17:00", nil, "anchor",
         "Muscle glycogen is the primary fuel for strength training. Going into a Forge Breechay session glycogen-depleted produces 10–20% lower force output, higher perceived effort, and blunted muscle protein synthesis response. Sourdough + nut butter = fast carbs + fat buffer to slow glucose spike = sustained energy through a 60+ min session. Skipping this is the #1 performance and body-comp mistake in the protocol. ~400 kcal · 55g carbs."),

        ("Post-lift anabolic window",   .health,       10,
         "Pumpkin seed shake in regular milk · banana OR watermelon OR strawberries.\nShake + fruit. Within 30 min of last set. Non-negotiable.",
         "Within 30 min of finishing gym",            .daily,  "18:30", nil, "anchor",
         "Post-training anabolic window is real and narrow for this context. Insulin sensitivity in muscle is highest in the 30–45 min post-exercise window. Carbohydrate + protein together here produces a greater anabolic response than protein alone. Miss this window and muscle glycogen replenishment is slower, muscle protein synthesis signal is blunted. On a cut this matters more, not less — you have less margin. ~480 kcal · 42g P."),

        ("Final meal",                  .health,       5,
         "120–150g roasted chicken · avocado · spinach/arugula · olive oil.\nChicken + avocado + greens. Kitchen closed at 8:30 PM — no pre-sleep protein.",
         "7:30–8:00 PM — before shutdown corridor",   .daily,  "19:30", nil, nil,
         "Last protein anchor of the day — ~50g here plus post-lift shake covers the 190g target. Kitchen closed by 8:30 supports sleep and a light stomach. No casein or bedtime shake required when daily protein is distributed across earlier meals."),

    ]
    for (title, system, points, note, cue, recurrence, block, dayType, tier, mechanism) in defaults {
        if PrescribedStackRetirement.isRetiredActionTitle(title) { continue }
        if let filter = onlyTitles, !filter.contains(title) { continue }
        let action = Action(
            title: title, system: system, points: points,
            recurrence: recurrence, note: note, cue: cue,
            scheduledBlock: block, dayTypeRaw: dayType,
            priorityTierRaw: tier, mechanismNote: mechanism
        )
        context.insert(action)
    }
}

func seedDefaultSessions(context: ModelContext, onlyTitles: Set<String>? = nil) {
    let defaults: [(String, SystemTag, [String], String, RecurrenceType)] = [
        (
            "Morning Protocol",
            .health,
            [
                "5:00 — Wake. No phone. Open blinds.",
                "5:02 — Water (500ml) + weigh in (post-bathroom) + Garmin HRV glance",
                "5:06 — Creatine (5g) — skip if on planned pause",
                "5:10 — Core + AM activation (Physique) — then fasted cardio (skip Mon/Fri if Rod 6:15)",
                "5:45 — Cold finish (last 2 min of shower cold)",
                "5:48 — Grooming corridor: cleanse → niacinamide → eye cream → SPF → lip balm → body lotion → deodorant → brush teeth AM",
                "6:05 — Protein first meal (30g minimum)",
                "6:10 — Journal (3 sentences)",
                "Mon/Fri 6:15 — Rod · Panorama (coaching)",
                "Leave ~6:30 on Hideout days"
            ],
            "5:00 AM wake target",
            .daily
        ),
        (
            "Evening Shutdown",
            .operations,
            [
                "8:25 — PM oral care: floss → brush → tongue scraper",
                "8:28 — Lights to lamps. Phone to other room.",
                "8:30 — No screens begins",
                "8:35 — Minoxidil (dry scalp, 45 min dry time needed)",
                "8:40 — Magnesium glycinate (400mg)",
                "8:45 — Stage tomorrow: bag packed, outfit set, kitchen staged, app open",
                "8:50 — Read (physical book, 20+ pages)",
                "8:55 — Kitchen closed. Light stomach — protein target hit by final meal.",
                "9:15 — Lights out. Side sleep position."
            ],
            "8:25 PM — hard start",
            .daily
        ),
        (
            "Whole Human Reset",
            .health,
            [
                "Face cleanse — Cetaphil Gentle Cleanser. Wet face first. Pea-sized amount. Fingertips only — no washcloth (too abrasive). Circular motion 60–90 sec, all zones including hairline and jawline. Rinse with lukewarm water — not hot, not cold. Pat dry, never rub. Damp skin is ideal for the next step — don't wait for fully dry.",
                "Vitamin C serum — 10–15% L-ascorbic. Apply after cleanse on dry or slightly damp skin. 3–5 drops, press into face and neck. Wait 30–60 sec before moisturizer. Antioxidant layer for even tone and Miami UV recovery — separate from pre-lift collagen vitamin C (that's internal).",
                "Eye cream — ring finger only, always. Index and middle fingers apply too much pressure to periorbital skin (thinnest on the body — ages fastest). Tap, don't rub or drag. Start at outer corner, tap inward along orbital bone. Under-eye and brow bone. Amount: rice grain per eye. Apply before moisturizer so it contacts skin directly.",
                "Moisturizer — Cetaphil Moisturizing Cream or Lotion. Damp skin absorbs 4–5x better than dry. Face + neck + décolletage. Upward strokes. Niacinamide moves to PM rotation nights (Mon/Thu) — not stacked in AM unless skipping Vit C.",
                "SPF — non-negotiable. Two-finger-length rule: squeeze SPF along index and middle fingers, that's the correct dose for face + neck. Apply face first, then neck, ears (including behind ears — often burned), backs of hands. Miami UV index is 10–11 year-round. UVA ages skin regardless of burning; you don't need to feel the sun to be damaged. Apply last — over moisturizer, under makeup if any.",
                "Lip balm SPF 30+ — lips have zero melanin. They sunburn faster than any other facial skin and are a primary site for squamous cell carcinoma. Separate application from face SPF because lips need a dedicated product. EltaMD UV Lip Balm or similar. Reapply after eating, drinking, at midday. Takes 3 seconds.",
                "Body lotion — apply to still-damp skin within 3 minutes of shower. This is the mechanism: damp skin traps moisture as lotion seals it in; dry skin just sits on top. Full sweep: arms (elbows need extra — the skin is thicker and drier), shoulders, chest, stomach, back of knees, shins, feet. Feet especially — daily standing and walking dries the heel fast. Cetaphil or similar fragrance-free. Takes 90 seconds done right.",
                "Deodorant / antiperspirant — apply to completely dry underarms. Antiperspirant works by blocking sweat ducts with aluminum compounds; moisture degrades effectiveness. If using aluminum-free: apply at night to clean dry skin — more effective timing because sweat is lower during sleep, allowing skin to absorb the active ingredients. For active outdoor café work: clinical strength or prescription-strength if standard isn't holding.",
                "Brush teeth — critical sequence note: do NOT brush immediately after the protein shake or matcha. Acidic drinks temporarily soften enamel; brushing within 20–30 min of them erodes it. Eat/drink first, wait 20 min, then brush. Technique: 45-degree angle to gumline, short strokes, 2 full minutes. Don't rinse with water after — spit only, let fluoride contact enamel for 30 sec. Tongue: brush or scrape back to front 2–3 passes."
            ],
            "After morning shower — grooming corridor 5:48–6:02",
            .daily
        ),
        (
            "Shutdown Preservation",
            .health,
            [
                "Face cleanse — PM cleanse is more important than AM. You're removing SPF (which oxidizes during the day and becomes mildly irritating), sweat, environmental pollutants, and any sebum buildup. Cetaphil Gentle Cleanser. Same technique: lukewarm water, circular motion 60–90 sec, pat dry. Do NOT skip this because you're tired — sleeping in oxidized SPF and sweat accelerates skin aging more than almost anything else.",
                "PM weekly rotation — one treatment only: Mon niacinamide · Tue glycolic AHA · Wed retinol · Thu niacinamide · Fri BHA · Sat retinol · Sun rest (cleanse + moisturizer). Never retinol + exfoliant same night. Full detail: Physique → Skin.",
                "Niacinamide (Mon/Thu PM) — 10% · 3–4 drops · dry skin after cleanse. Skip on retinol and exfoliant nights.",
                "Glycolic acid (Tue PM) / BHA (Fri PM) — apply to dry face, 10–15 min after cleanse. Thin layer, avoid eye area. Leave-on — not rinse-off. Don't combine with retinol same night.",
                "Retinol (Wed/Sat PM) — pea-sized · dry skin 10–20 min post-cleanse · dot forehead, cheeks, chin · avoid eyes and mouth corners · moisturizer after.",
                "Moisturize PM — can be heavier than AM moisturizer since no SPF needed and skin repairs overnight. Cetaphil is fine. Apply to slightly damp skin after any treatment products.",
                "Body lotion — feet especially. Heel fissures develop from daily standing; applying lotion PM and wearing socks overnight (even briefly) prevents cracking that becomes painful during cardio. Arms, elbows, knees if you skipped AM.",
                "Floss first — floss before brushing, always. Reason: flossing releases interdental plaque and bacteria; brushing then sweeps them away. If you brush first, flossing moves bacteria around but doesn't clear them. C-shape around each tooth, below gumline, gentle vertical motion. Water flosser is fine as substitute — equally effective if used correctly.",
                "Brush teeth PM — 2 min. Same 45-degree angle technique. This is the more important brush of the day: you're removing a full day of bacterial buildup before an 8+ hour fast. Spit, don't rinse with water — let fluoride work overnight.",
                "Tongue scraper — 2–3 firm passes from back to front. Rinse between passes. Do this after brushing. The tongue surface harbors more bacteria than anywhere else in the mouth — standard brushing doesn't reach the posterior third effectively. Copper or stainless > plastic (antimicrobial properties).",
                "Minoxidil — dry scalp. Completely dry. Moisture on the scalp dilutes the solution and reduces absorption. Apply to crown and top — the thinning zone. Thin spread, not saturated. Must dry 45+ min before pillow contact or it transfers to fabric and you lose the dose. If using derma roller tonight (Wed or Sun), apply minoxidil within 30 min of rolling while channels are open."
            ],
            "After no-screens begins — before sleep",
            .daily
        ),
        (
            "Weekly Reset",
            .operations,
            [
                "What closed this week? — name specific things that are done and don't need to re-enter your head. Not 'I made progress on X.' Closed means closed. If it's not closed, it carries forward.",
                "What carries forward? — active fronts only. If something carried forward 3 weeks in a row without movement, it's either not real or it's blocked. Name the block, not the task.",
                "What needs a decision this week? — distinguish between tasks (do it) and decisions (requires information or judgment). Decisions that sit undecided consume cognitive background load. Make the decision or schedule when you will.",
                "Financial pulse — Hideout: what was this week's daily average, is it trending toward the right band, what's the cash position. Personal: anything irregular this week. 3 numbers, 2 minutes, not a full review.",
                "Growth / visibility action this week? — did any planned board, card, partnership, or GBP action happen? If not, why not? One action per week minimum.",
                "Physical reset — clean the apartment, prep the week's food infrastructure, anything environmental that will cause drag if not handled now.",
                "Set first action for Monday morning — written, specific, doable before 9AM. Not a list. One thing. The thing that, if you did only that, Monday wouldn't feel wasted."
            ],
            "Sunday evening — 7:00 PM · 30 min",
            .weekly
        ),
        (
            "Laundry",
            .environment,
            [
                "Sort first: darks / lights / colors separate. Whites with whites — one mixed load of lights and darks over time creates a permanent grey tint on white items that can't be reversed. Gym clothes separate from regular clothes — athletic fabric holds odor and the bacteria transfers.",
                "Water temperature: cold for darks and colors (prevents fading, saves energy), warm for lights and linens, hot only for towels and white athletic wear (kills bacteria). Hot water shrinks most fabrics — when in doubt, cold.",
                "Detergent: less than you think. The measuring lines on cups are 2–3x more than needed. Excess detergent doesn't rinse out fully and leaves residue that traps odor — this is why gym clothes smell after washing. Half the cap is usually correct. For whites: add half cup white vinegar to the rinse cycle, not bleach — vinegar maintains brightness without fabric damage.",
                "Athletic / gym wear: turn inside out — the odor is from bacteria on the skin-contact side. Cold water, gentle cycle. No fabric softener ever on athletic wear — it coats the performance fibers and prevents moisture wicking. This is irreversible damage. Use white vinegar instead.",
                "Move to dry promptly — clothes sitting wet in the drum for more than 2 hours develop mildew smell that survives drying. If you forget, rewash.",
                "Dryer: low heat for athletic wear, dress shirts, anything with elastic or spandex. Medium for most items. High only for towels, sheets, heavy cotton. Overdrying with high heat is what shrinks and degrades fabric over time — not washing.",
                "Fold or hang immediately out of dryer. Leaving folded in the drum for hours creates wrinkles that require ironing. 5 minutes folding when warm vs 20 minutes ironing later.",
                "Shoes and socks: don't machine wash shoes unless they're specifically machine-washable. Remove insoles, hand wash or wipe shell, air dry. Socks: washing inside out removes dead skin cells and bacteria from the inside surface more effectively."
            ],
            "Sunday — or when hamper is full",
            .none
        ),
        // Cognitive Sharpening — base days only. Not for hideout mornings (wrong environment, wrong energy state).
        // On hideout days, reading happens at 20:45 as the evening anchor.
        (
            "Cognitive Sharpening",
            .cognition,
            [
                "Phone in another room or silent",
                "Physical book only — no screen",
                "Read 20 pages minimum",
                "One sentence in journal: what landed"
            ],
            "Base days — after morning anchor, before ops work. Not during hideout shifts.",
            .daily
        ),
        // WATERMARC OUTREACH — highest-ROI visibility play per strategy brief
        (
            "Watermarc relationship touch",
            .participation,
            [
                "Bring coffee to leasing office",
                "Introduce Hideout — ask if they'll mention us on tours",
                "Leave cards with the concierge",
                "Note how many units in the building"
            ],
            "First available morning at Hideout — then monthly",
            .none
        ),

        (
            "Pre-Lift Mobility",
            .health,
            [
                "Hip flexor — 60 sec/side kneeling lunge",
                "Thoracic rotation — 10 reps/side seated",
                "Ankle circles — 10 each direction (tibia weeks)",
                "Dead hang — 30 sec optional after long Hideout shift"
            ],
            "5:25 PM — before first working set (optional)",
            .daily
        ),

        (
            "PM Oral Care",
            .health,
            [
                "Floss first — always before brushing, never after. Flossing dislodges bacteria and food from between teeth; brushing then sweeps them out of the mouth. If you brush first, flossing just moves bacteria around. C-shape: wrap floss around each tooth individually forming a C, slide below the gumline (1–2mm below where the tooth meets the gum), gentle vertical strokes against the tooth surface. Do every tooth, both sides. 60 sec total. Water flosser is acceptable substitute — use on lowest comfortable pressure, angle below gumline.",
                "Brush — 45-degree angle to gumline, not perpendicular. Small circular motions or gentle back-and-forth, 2 minutes. Quad method: 30 sec per quadrant. Don't press hard — the bristles do the work, not force. Scrubbing hard causes gum recession that can't be reversed. Get the inner surfaces (tongue side of lower front teeth is the most missed area). Brush tongue lightly. Spit — do NOT rinse with water after. The fluoride needs 30–60 sec contact with enamel to work; water immediately rinses it away before it can remineralize.",
                "Tongue scraper — after brushing. 2–3 firm passes from as far back as comfortable (you'll trigger gag reflex if you go too far — back off slightly) to the tip. Rinse the scraper between passes. The film you remove is bacterial biofilm, dead cells, and volatile sulfur compounds. This is the primary source of morning breath and also a systemic health factor — oral bacteria aspirated during sleep is linked to respiratory and cardiovascular risk. Copper or stainless steel is antimicrobial; plastic just moves the biofilm around."
            ],
            "8:25 PM — before shutdown corridor",
            .daily
        ),
    ]
    for (title, system, steps, cue, recurrence) in defaults {
        if let filter = onlyTitles, !filter.contains(title) { continue }
        context.insert(Session(title: title, system: system, steps: steps, cue: cue, recurrence: recurrence))
    }
}


// Spec (Design Decisions v1.2 · CARE 03):
// Nodes pulse in one by one (1.2s) → warm corona ignites (0.3s) → wordmark fades up (0.4s) → app loads
// Total ~2.2s. Runs once per cold launch. Static thereafter — instrument mode engaged.

struct LaunchSequenceView: View {
    var onComplete: () -> Void

    // 12 neural nodes — positions tuned to the actual AppIcon (top-down brain, 180pt rendered size)
    // Warm gold nodes sit over the icon's existing node positions
    private let nodePositions: [(CGFloat, CGFloat)] = [
        // Left hemisphere
        (-32, -58), (-54, -28), (-58,  10), (-44,  44), (-18,  60),
        (-24,  -8),
        // Right hemisphere
        ( 32, -58), ( 54, -28), ( 58,  10), ( 44,  44), ( 18,  60),
        ( 24,  -8),
    ]

    // Connections between node indices (pairs)
    private let connections: [(Int, Int)] = [
        (0,1),(1,2),(2,3),(3,4),(4,10),(1,5),(5,2),(5,9),
        (6,7),(7,8),(8,9),(9,10),(7,11),(11,8),(11,3),
        (0,6),(5,11)   // corpus callosum bridges
    ]

    @State private var nodeVisible:    [Bool]   = Array(repeating: false, count: 12)
    @State private var nodeGlow:       [Bool]   = Array(repeating: false, count: 12)
    @State private var coronaOpacity:  Double   = 0
    @State private var coronaRadius:   CGFloat  = 40
    @State private var wordmarkOpacity: Double  = 0
    @State private var wordmarkOffset:  CGFloat = 12
    @State private var sublineOpacity:  Double  = 0
    @State private var connectionOpacity: Double = 0

    var body: some View {
        ZStack {
            Color.bgBase.ignoresSafeArea()

            VStack(spacing: 0) {
                Spacer()

                // Brain glyph + nodes
                ZStack {
                    // Warm corona — ignites after nodes
                    RadialGradient(
                        colors: [
                            Color.warm.opacity(0.55 * coronaOpacity),
                            Color.violet.opacity(0.18 * coronaOpacity),
                            Color.bgBase.opacity(0)
                        ],
                        center: .center,
                        startRadius: coronaRadius * 0.3,
                        endRadius: coronaRadius
                    )
                    .frame(width: coronaRadius * 2, height: coronaRadius * 2)
                    .blur(radius: 18)
                    .animation(.easeOut(duration: 0.35), value: coronaOpacity)

                    // BrainGlyph — transparent-background asset from xcassets
                    Image("BrainGlyph")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 180, height: 180)
                        .shadow(color: Color.violet.opacity(0.35), radius: 32)
                        .shadow(color: Color.warm.opacity(0.2), radius: 16)

                    // Connection lines — appear with nodes
                    Canvas { ctx, size in
                        let center = CGPoint(x: size.width / 2, y: size.height / 2)
                        for (a, b) in connections {
                            guard nodeVisible[a] && nodeVisible[b] else { continue }
                            let pa = CGPoint(
                                x: center.x + nodePositions[a].0,
                                y: center.y + nodePositions[a].1
                            )
                            let pb = CGPoint(
                                x: center.x + nodePositions[b].0,
                                y: center.y + nodePositions[b].1
                            )
                            var path = Path()
                            path.move(to: pa)
                            path.addLine(to: pb)
                            ctx.stroke(
                                path,
                                with: .color(Color.warm.opacity(0.25 * connectionOpacity)),
                                lineWidth: 0.6
                            )
                        }
                    }
                    .frame(width: 180, height: 180)
                    .animation(.easeIn(duration: 0.2), value: connectionOpacity)

                    // Neural nodes
                    ForEach(nodePositions.indices, id: \.self) { i in
                        Circle()
                            .fill(Color.warm)
                            .frame(width: nodeGlow[i] ? 5 : 3.5, height: nodeGlow[i] ? 5 : 3.5)
                            .shadow(color: Color.warm.opacity(nodeGlow[i] ? 0.9 : 0.4),
                                    radius: nodeGlow[i] ? 6 : 2)
                            .offset(x: nodePositions[i].0, y: nodePositions[i].1)
                            .opacity(nodeVisible[i] ? 1 : 0)
                            .scaleEffect(nodeVisible[i] ? 1 : 0.1)
                            .animation(.spring(response: 0.25, dampingFraction: 0.6), value: nodeVisible[i])
                            .animation(.easeInOut(duration: 0.3), value: nodeGlow[i])
                    }
                }
                .frame(width: 180, height: 180)
                .padding(.bottom, 44)

                // Wordmark
                VStack(spacing: 10) {
                    Text("INCREMENTS")
                        .font(.custom("Sora", size: 28).weight(.light))
                        .foregroundColor(.textPrimary)
                        .tracking(10)

                    Text("environmental cognition support system")
                        .font(.custom("DM Mono", size: 10).weight(.light))
                        .foregroundColor(.textMuted)
                        .tracking(2)
                }
                .opacity(wordmarkOpacity)
                .offset(y: wordmarkOffset)
                .animation(.easeOut(duration: 0.45), value: wordmarkOpacity)
                .animation(.easeOut(duration: 0.45), value: wordmarkOffset)

                Spacer()

                // Bottom line — appears with wordmark
                Text("participation in reality")
                    .font(.custom("DM Mono", size: 9))
                    .foregroundColor(.textMuted.opacity(0.5))
                    .tracking(3)
                    .padding(.bottom, 52)
                    .opacity(sublineOpacity)
                    .animation(.easeOut(duration: 0.4), value: sublineOpacity)
            }
        }
        .onAppear { runSequence() }
    }

    private func runSequence() {
        // Phase 1: nodes pulse in one by one over 1.2s
        // Stagger: 12 nodes × ~90ms each, with slight randomisation for organic feel
        let staggerBase = 0.08
        for i in nodePositions.indices {
            let delay = Double(i) * staggerBase + Double.random(in: 0...0.03)
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                nodeVisible[i] = true
                // Brief glow burst on appearance
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { nodeGlow[i] = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { nodeGlow[i] = false }
            }
        }

        // Connection lines fade in as nodes appear
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            withAnimation { connectionOpacity = 1 }
        }

        // Phase 2: corona ignites (starts at 1.2s, takes 0.35s)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
            withAnimation(.easeOut(duration: 0.35)) {
                coronaOpacity = 1
                coronaRadius = 110
            }
            // Final node pulse — all glow together at corona moment
            for i in nodePositions.indices {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) { nodeGlow[i] = true }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.4)  { nodeGlow[i] = false }
            }
        }

        // Phase 3: wordmark fades up (starts at 1.55s, takes 0.45s)
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.55) {
            wordmarkOpacity = 1
            wordmarkOffset = 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                sublineOpacity = 1
            }
        }

        // Phase 4: hand off to app (2.25s total)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.25) {
            onComplete()
        }
    }
}

// MARK: - ONBOARDING
// First launch only. Not setup. A worldview entry point.
// The product selects its own user here.

struct OnboardingView: View {
    let onComplete: () -> Void
    @State private var page = 0
    @State private var appeared = false

    var body: some View {
        ZStack {
            Color.bgBase.ignoresSafeArea()
            AtmosphericBackground(enhanced: true)

            VStack(spacing: 0) {
                Spacer()

                // Page content
                Group {
                    switch page {
                    case 0: onboardPage0
                    case 1: onboardPage1
                    case 2: onboardPage2
                    case 3: onboardPage3
                    default: EmptyView()
                    }
                }
                .opacity(appeared ? 1 : 0)
                .offset(y: appeared ? 0 : 20)
                .animation(.easeOut(duration: 0.5), value: appeared)
                .animation(.easeOut(duration: 0.5), value: page)

                Spacer()

                // Navigation
                HStack {
                    // Page dots
                    HStack(spacing: 6) {
                        ForEach(0..<4) { i in
                            Circle()
                                .fill(i == page ? Color.violetLight : Color.muted.opacity(0.3))
                                .frame(width: i == page ? 6 : 4, height: i == page ? 6 : 4)
                                .animation(.easeOut(duration: 0.2), value: page)
                        }
                    }
                    Spacer()
                    Button(action: advance) {
                        HStack(spacing: 6) {
                            Text(page < 3 ? "Continue" : "Enter")
                                .font(.sora(14, weight: .medium))
                            Image(systemName: page < 3 ? "arrow.right" : "arrow.forward")
                                .font(.system(size: 12, weight: .medium))
                        }
                        .foregroundColor(page < 3 ? .textPrimary : .bgBase)
                        .padding(.horizontal, 20).padding(.vertical, 12)
                        .background(page < 3 ? Color.surface : Color.violet)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
                .padding(.horizontal, 36).padding(.bottom, 52)
                .opacity(appeared ? 1 : 0)
                .animation(.easeOut(duration: 0.4).delay(0.3), value: appeared)
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { appeared = true }
        }
    }

    func advance() {
        if page < 3 {
            withAnimation(.easeOut(duration: 0.3)) {
                appeared = false
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                page += 1
                withAnimation { appeared = true }
            }
        } else {
            onComplete()
        }
    }

    // ── Page 0: Operating model (corrected) ─────────────────────
    var onboardPage0: some View {
        VStack(alignment: .leading, spacing: 32) {
            VStack(alignment: .leading, spacing: 10) {
                MonoLabel(text: "INCREMENTS", color: .violetLight, size: 11)
                Text("This system assumes.")
                    .font(.sora(28, weight: .semibold)).foregroundColor(.textPrimary)
                    .lineSpacing(4)
            }

            VStack(alignment: .leading, spacing: 16) {
                assumption("Execution is not your problem. Structure often is.", icon: "square.grid.2x2")
                assumption("Friction is usually architectural, not motivational.", icon: "wrench.adjustable")
                assumption("Task arrangement changes execution quality.", icon: "list.number")
                assumption("Environment shapes cognition.", icon: "house")
                assumption("Accurate self-models release bandwidth.", icon: "brain")
            }
        }
        .padding(.horizontal, 36)
    }

    // ── Page 1: Two surfaces ─────────────────────────────────────
    var onboardPage1: some View {
        VStack(alignment: .leading, spacing: 32) {
            VStack(alignment: .leading, spacing: 10) {
                MonoLabel(text: "ARCHITECTURE", color: .warm, size: 11)
                Text("Two surfaces.\nOne purpose.")
                    .font(.sora(28, weight: .semibold)).foregroundColor(.textPrimary)
                    .lineSpacing(4)
            }

            VStack(alignment: .leading, spacing: 20) {
                surfaceCard(
                    label: "TODAY",
                    description: "Execute. Sequence. Complete. The execution surface reduces cognitive load — it never adds it.",
                    color: .inkAmber,
                    icon: "calendar"
                )
                surfaceCard(
                    label: "OPERATOR",
                    description: "Brief me. Detect friction. Understand the structure. The intelligence surface improves routing.",
                    color: .violetLight,
                    icon: "brain"
                )
            }
        }
        .padding(.horizontal, 36)
    }

    // ── Page 2: Intelligence doctrine ───────────────────────────
    var onboardPage2: some View {
        VStack(alignment: .leading, spacing: 32) {
            VStack(alignment: .leading, spacing: 10) {
                MonoLabel(text: "INTELLIGENCE LAYER", color: .inkGreen, size: 11)
                Text("Coordination.\nNot motivation.")
                    .font(.sora(28, weight: .semibold)).foregroundColor(.textPrimary)
                    .lineSpacing(4)
            }

            VStack(alignment: .leading, spacing: 14) {
                Text("The system detects structural friction — sequencing issues, fragmentation, operational displacement, environmental drag.")
                    .font(.sora(15, weight: .light)).foregroundColor(.textPrimary).lineSpacing(4)
                Text("It does not activate. It does not motivate. It reduces the drag on a system that already moves.")
                    .font(.sora(15, weight: .light)).foregroundColor(.textSecond).lineSpacing(4)
                Text("Agency remains with the operator.")
                    .font(.mono(12)).foregroundColor(.violetLight).tracking(0.5)
            }
        }
        .padding(.horizontal, 36)
    }

    // ── Page 3: Enter ────────────────────────────────────────────
    var onboardPage3: some View {
        VStack(alignment: .leading, spacing: 32) {
            VStack(alignment: .leading, spacing: 10) {
                MonoLabel(text: "DAY 1", color: .textMuted, size: 11)
                Text("The system starts\nat zero.")
                    .font(.sora(28, weight: .semibold)).foregroundColor(.textPrimary)
                    .lineSpacing(4)
            }

            VStack(alignment: .leading, spacing: 14) {
                Text("Seven days of data opens the pattern window. The intelligence layer builds from observed behavior, not declared identity.")
                    .font(.sora(15, weight: .light)).foregroundColor(.textSecond).lineSpacing(4)
                Text("Open Today. Sequence the work. Move.")
                    .font(.sora(15, weight: .light)).foregroundColor(.textPrimary).lineSpacing(4)
            }
        }
        .padding(.horizontal, 36)
    }

    // ── Helpers ──────────────────────────────────────────────────
    func assumption(_ text: String, icon: String) -> some View {
        HStack(spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 14, weight: .light))
                .foregroundColor(.violetLight)
                .frame(width: 20)
            Text(text)
                .font(.sora(15, weight: .light)).foregroundColor(.textPrimary).lineSpacing(3)
        }
    }

    func surfaceCard(label: String, description: String, color: Color, icon: String) -> some View {
        HStack(alignment: .top, spacing: 14) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .light))
                .foregroundColor(color)
                .frame(width: 24)
                .padding(.top, 2)
            VStack(alignment: .leading, spacing: 5) {
                MonoLabel(text: label, color: color, size: 11)
                Text(description)
                    .font(.sora(13, weight: .light)).foregroundColor(.textSecond).lineSpacing(3)
            }
        }
        .padding(16)
        .background(color.opacity(0.05))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12)
            .strokeBorder(color.opacity(0.15), lineWidth: 0.5))
    }
}

// MARK: - ROOT VIEW

struct RootView: View {
    @EnvironmentObject private var cloudSync: CloudSyncPreferences
    @EnvironmentObject private var cloudKitMonitor: CloudKitSyncMonitor
    @State private var state = AppState()
    @Query private var profiles: [OperatorProfile]
    @Query private var actions: [Action]
    @Query private var hideoutShifts: [HideoutShiftLog]
    @Query private var partnerAccounts: [PartnerAccount]
    @Environment(\.modelContext) private var context
    @Environment(\.scenePhase) private var scenePhase
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding = false

    var profile: OperatorProfile { profiles.first ?? OperatorProfile() }

    // 8-tab nav: Now / Today / Protocols / Physique / Hideout / Signal / You / Recovery
    // Manual moved into You sub-tabs. Physique = active body-comp cut operating domain.
    var showTimeline: Bool { true }   // kept for CustomTabBar compat

    @ViewBuilder
    func tabView(for index: Int) -> some View {
        switch index {
        case 0: HomeView(state: state)
        case 1: TodayView(state: state)
        case 2: ProtocolsTabView()
        case 3: PhysiqueTabView()
        case 4: HideoutTabView()
        case 5: SignalTabView()
        case 6: YouView(state: state)
        case 7: RecoveryTabView()
        default: HomeView(state: state)
        }
    }

    @Query private var sessions: [Session]
    @Query private var maintenanceItems: [MaintenanceItem]
    @Query private var habits: [Habit]
    @Query private var financialStates: [FinancialState]

    var body: some View {
        let _ = cloudSync.revision
        return AppMetricsProvider {
        ZStack(alignment: .bottom) {
            tabView(for: state.selectedTab)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            CustomTabBar(selected: $state.selectedTab, showTimeline: showTimeline)
        }
        .ignoresSafeArea(edges: .bottom)
        .fullScreenCover(isPresented: .constant(!hasCompletedOnboarding)) {
            OnboardingView(onComplete: { hasCompletedOnboarding = true })
        }
        .onAppear {
            if profiles.isEmpty {
                let p = OperatorProfile()
                p.operatorName = "Brice"   // seed name — user can change in Settings
                context.insert(p)
            }
            if actions.isEmpty {
                seedDefaultActions(context: context)
            }
            if sessions.isEmpty {
                seedDefaultSessions(context: context)
            }
            // Always normalize — retire legacy rows, dedupe CloudKit ghosts, seed missing core.
            // Skipping when actions.isEmpty was leaving post-wipe / iCloud re-import clutter visible.
            PrescribedStackRetirement.normalize(context: context)
            if maintenanceItems.isEmpty { seedDefaultMaintenance(context: context) }
            seedMissingConductFilterItems(context: context, maintenance: maintenanceItems, habits: habits)
            seedHideoutAppLaunchMaintenance(context: context, maintenance: maintenanceItems)
            if financialStates.isEmpty { context.insert(FinancialState()) }
            // Seed Week 1 solo experiment data (May 13–17, 2026) if no shifts exist.
            // Gated on hideoutShifts.isEmpty — only runs on fresh install or after data wipe.
            if hideoutShifts.isEmpty {
                seedWeek1Shifts(context: context)
            } else {
                dedupeHideoutShiftsByDay(context: context, shifts: hideoutShifts)
            }
            // Seed partner accounts — Jimmy (active) + pipeline prospects from brief.
            if partnerAccounts.isEmpty { seedDefaultPartnerAccounts(context: context) }
            if let p = profiles.first {
                // BUG FIX: reset recurring actions each new calendar day
                resetDailyActionsIfNeeded(context: context, profile: p, actions: actions, sessions: sessions)
                // BUG FIX: restore systemLastActivity from persisted completionDates on launch.
                // Without this, Now View "X hasn't moved" signal and nextSaneAction sorting
                // were always wrong on cold launch (in-memory only, lost on restart).
                restoreSystemLastActivity(state: state, actions: actions)
                // Sync voice preference from persisted profile
                VoicePresence.shared.voiceEnabled = p.voicePresenceEnabled
                VoicePresence.shared.provider = p.voiceProvider
                VoicePresence.shared.elevenLabsVoiceId = p.elevenLabsVoiceId
                VoicePresence.shared.elevenLabsApiKey = p.elevenLabsApiKey
                VoicePresence.shared.openAIApiKey = p.openAIApiKey
            }
            #if canImport(UserNotifications)
            NotificationService.shared.requestPermission()
            #endif
        }
        // BUG FIX: also run daily reset when app returns from background (e.g. opened next morning).
        // Without this, actions only reset on cold launch — leaving yesterday's state visible
        // if the app was backgrounded overnight and re-foregrounded the next day.
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                if let p = profiles.first {
                    resetDailyActionsIfNeeded(context: context, profile: p, actions: actions, sessions: sessions)
                    restoreSystemLastActivity(state: state, actions: actions)
                }
                // CloudKit may import stale actions after foreground — re-normalize once sync settles.
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    PrescribedStackRetirement.normalize(context: context)
                }
            } else if newPhase == .background {
                cloudSync.pushLocalDefaultsToCloud()
            }
        }
        .onChange(of: cloudKitMonitor.lastUpdated) { _, _ in
            PrescribedStackRetirement.normalize(context: context)
        }
        } // end AppMetricsProvider
    }
}

// BUG FIX: rebuild in-memory systemLastActivity from persisted completionDates.
// Called on launch and foreground re-entry. Gives Now View accurate "days since activity"
// data for the nextSaneAction picker and synergy subline, which previously reset to
// "999 days" on every cold launch.
func restoreSystemLastActivity(state: AppState, actions: [Action]) {
    for system in SystemTag.allCases {
        let systemActions = actions.filter { $0.system == system }
        // Find the most recent completion date across all actions in this system
        let latestCompletion = systemActions.compactMap { $0.completionDates.last }.max()
        if let latest = latestCompletion {
            // Only update if this is more recent than what's already in memory
            if let existing = state.systemLastActivity[system] {
                if latest > existing { state.systemLastActivity[system] = latest }
            } else {
                state.systemLastActivity[system] = latest
            }
        }
    }
}

// MARK: - APP ENTRY POINT

// MARK: - SWIFTDATA MIGRATION PLAN
// Lightweight migration: new fields added to existing models get their default values.
// No data is destroyed. Rebuilding the app preserves all user data.
//
// HOW TO ADD NEW FIELDS IN FUTURE:
// 1. Add the field to the model class with a default value
// 2. Add a new VersionedSchema (e.g. SchemaV3) with the updated models
// 3. Add a MigrationStage.lightweight(fromVersion: SchemaV2.self, toVersion: SchemaV3.self)
// 4. Update INCREMENTSMigrationPlan.stages and INCREMENTSApp.container to use the new schema

// SCHEMA MIGRATION NOTES:
// SwiftData checksums the MODEL SET (the actual list of @Model classes), not the version number.
// Two VersionedSchema enums with the same model list = identical checksum = crash on launch.
// Rule: every schema in the migration plan must have a DIFFERENT set of models from all others.
//
// History of distinct model-set snapshots:
//   V1 — original base models. Acts as the entry point for any store built before V4 was defined.
//         Without this, staged migration throws "unknown model version" for old installs.
//   V4 — added MaintenanceItem, HydrationLog, FinancialState, ConsultReceipt.
//   V6 — added HideoutShiftLog (+ lastWendyObservation on OperatorProfile via lightweight default).
//
// Removed from staged plan (duplicate checksum with V4/V6 if re-added with same model set):
//   V2, V3 — same models as V4
//   V5     — same models as V6
// Stores tagged with those version ids recover via IncrementsPersistentStore store wipe + rebuild.

enum SchemaV1: VersionedSchema {
    static var versionIdentifier = Schema.Version(1, 0, 0)
    // Entry point for stores created before the V4 schema was formally defined.
    // Covers any "unknown" old version — gives staged migration a valid starting node.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self]
    }
}

enum SchemaV4: VersionedSchema {
    static var versionIdentifier = Schema.Version(4, 0, 0)
    // Added MaintenanceItem, HydrationLog, FinancialState, ConsultReceipt.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self]
    }
}

enum SchemaV6: VersionedSchema {
    static var versionIdentifier = Schema.Version(6, 0, 0)
    // V6 = current schema. All new fields added to existing models use default values
    // and are handled by SwiftData automatically — no schema bump needed.
    //
    // HOW TO ADD A NEW @Model CLASS (future):
    // 1. Define the class in Models.swift with @Model + default values on all fields
    // 2. Add SchemaV7 below with the full model list including the new class
    // 3. Add .lightweight(fromVersion: SchemaV6.self, toVersion: SchemaV7.self) to stages
    // 4. Update INCREMENTSMigrationPlan.schemas and the ModelContainer schema list
    //
    // HOW TO ADD A NEW FIELD TO AN EXISTING MODEL (no schema bump needed):
    // 1. Add the field with a default value: var myField: String = ""
    // 2. SwiftData migrates it automatically on next launch. No deletion required.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self, HideoutShiftLog.self]
    }
}

enum SchemaV7: VersionedSchema {
    static var versionIdentifier = Schema.Version(7, 0, 0)
    // V7 adds FridaySignalLog + PartnerAccount models.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self, HideoutShiftLog.self, FridaySignalLog.self,
         PartnerAccount.self]
    }
}

enum SchemaV8: VersionedSchema {
    static var versionIdentifier = Schema.Version(8, 0, 0)
    // V8 adds TibiaRecoveryLog for tibia IM nail recovery signal tracking.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self, HideoutShiftLog.self, FridaySignalLog.self,
         PartnerAccount.self, TibiaRecoveryLog.self]
    }
}

enum SchemaV9: VersionedSchema {
    static var versionIdentifier = Schema.Version(9, 0, 0)
    // V9 adds Signal tab models: DistributionWeek + DecisionLedger.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self, HideoutShiftLog.self, FridaySignalLog.self,
         PartnerAccount.self, TibiaRecoveryLog.self,
         DistributionWeek.self, DecisionLedger.self]
    }
}

enum SchemaV10: VersionedSchema {
    static var versionIdentifier = Schema.Version(10, 0, 0)
    // V10 adds physique practice logs + TibiaRecoveryLog Phase 2 gate fields.
    static var models: [any PersistentModel.Type] {
        [Action.self, Habit.self, OperatorProfile.self,
         DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
         Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
         ConsultReceipt.self, HideoutShiftLog.self, FridaySignalLog.self,
         PartnerAccount.self, TibiaRecoveryLog.self,
         DistributionWeek.self, DecisionLedger.self,
         CoreCompletionLog.self, AMActivationLog.self]
    }
}

enum INCREMENTSMigrationPlan: SchemaMigrationPlan {
    static var schemas: [any VersionedSchema.Type] {
        [SchemaV1.self, SchemaV4.self, SchemaV6.self, SchemaV7.self, SchemaV8.self, SchemaV9.self, SchemaV10.self]
    }
    static var stages: [MigrationStage] {
        [
            .lightweight(fromVersion: SchemaV1.self, toVersion: SchemaV4.self),
            .lightweight(fromVersion: SchemaV4.self, toVersion: SchemaV6.self),
            .lightweight(fromVersion: SchemaV6.self, toVersion: SchemaV7.self),
            .lightweight(fromVersion: SchemaV7.self, toVersion: SchemaV8.self),
            .lightweight(fromVersion: SchemaV8.self, toVersion: SchemaV9.self),
            .lightweight(fromVersion: SchemaV9.self, toVersion: SchemaV10.self),
        ]
    }
}

// MARK: - SwiftData store bootstrap (CloudKit + migration recovery)

private enum IncrementsPersistentStore {
    static let schema = Schema([
        Action.self, Habit.self, OperatorProfile.self,
        DailyLog.self, WorkTrack.self, RecoveryPhase.self, CognitionLog.self,
        Session.self, MaintenanceItem.self, HydrationLog.self, FinancialState.self,
        ConsultReceipt.self, HideoutShiftLog.self, FridaySignalLog.self,
        PartnerAccount.self, TibiaRecoveryLog.self,
        DistributionWeek.self, DecisionLedger.self,
        CoreCompletionLog.self, AMActivationLog.self
    ])

    private static let cloudKitContainer = "iCloud.com.brice.Increments"

    /// Removes SwiftData SQLite store and WAL/SHM sidecars (same paths Core Data uses).
    static func wipeStoreFiles(at storeURL: URL) {
        let fm = FileManager.default
        let directory = storeURL.deletingLastPathComponent()
        let stem = storeURL.deletingPathExtension().lastPathComponent
        let candidates = [
            storeURL,
            directory.appendingPathComponent("\(stem).store-shm"),
            directory.appendingPathComponent("\(stem).store-wal"),
            directory.appendingPathComponent("\(stem).sqlite-shm"),
            directory.appendingPathComponent("\(stem).sqlite-wal"),
        ]
        for url in candidates where fm.fileExists(atPath: url.path) {
            try? fm.removeItem(at: url)
        }
    }

    static func makeContainer() -> ModelContainer {
        let localConfig = ModelConfiguration(schema: schema)
        let cloudConfig = ModelConfiguration(
            schema: schema,
            cloudKitDatabase: .private(cloudKitContainer)
        )

        do {
            return try ModelContainer(
                for: schema,
                migrationPlan: INCREMENTSMigrationPlan.self,
                configurations: [cloudConfig]
            )
        } catch {
            print("INCREMENTS: CloudKit store unavailable (\(error.localizedDescription)); trying local migration.")
        }

        do {
            return try ModelContainer(
                for: schema,
                migrationPlan: INCREMENTSMigrationPlan.self,
                configurations: [localConfig]
            )
        } catch {
            // Old installs may carry schema version ids (V2/V3/V5) removed from the staged plan.
            // Wipe local store and open fresh — seed data repopulates on next launch.
            print("INCREMENTS: Migration failed (\(error.localizedDescription)). Wiping store and rebuilding.")
            wipeStoreFiles(at: localConfig.url)
            do {
                return try ModelContainer(for: schema, configurations: [localConfig])
            } catch {
                fatalError("INCREMENTS: Could not open SwiftData store after rebuild (\(error.localizedDescription)).")
            }
        }
    }
}

@main
struct INCREMENTSApp: App {
    @StateObject private var cloudSync = CloudSyncPreferences.shared
    @StateObject private var cloudKitMonitor = CloudKitSyncMonitor.shared
    @State private var launchComplete = false
    // Prevents tappable elements rendering before SwiftData @Query results settle.
    // RootView stays invisible until both the launch animation finishes AND the store
    // has returned at least one result. On a cold launch the store is ready well before
    // the 2.25s animation completes, so in practice this adds zero perceptible delay.
    @State private var dataReady = false

    // ModelContainer with migration plan; falls back to local-only, then store rebuild.
    let container: ModelContainer = IncrementsPersistentStore.makeContainer()

    var body: some Scene {
        WindowGroup {
            ZStack {
                RootView()
                    .environmentObject(cloudSync)
                    .environmentObject(cloudKitMonitor)
                    .preferredColorScheme(.dark)
                    // Only become visible once both the launch animation is done AND the
                    // SwiftData store has settled. Eliminates the window where tappable rows
                    // appear but their backing data isn't ready yet.
                    .opacity(launchComplete && dataReady ? 1 : 0)
                    .onAppear {
                        cloudSync.bootstrap()
                        cloudKitMonitor.startObserving()
                        // Poll briefly for store readiness. On a real device the container is
                        // open well before the 2.25s animation ends, so this loop typically
                        // fires on the first or second tick and adds no perceptible delay.
                        func checkReady() {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
                                // RootView's @Query arrays are not directly visible here, but
                                // the ModelContainer being open is sufficient — mark ready.
                                // If you ever hit a race, increase the tick count.
                                dataReady = true
                            }
                        }
                        checkReady()
                    }

                if !launchComplete {
                    LaunchSequenceView {
                        withAnimation(.easeIn(duration: 0.35)) {
                            launchComplete = true
                        }
                    }
                    .transition(.opacity)
                }
            }
            .preferredColorScheme(.dark)
        }
        .modelContainer(container)
    }
}
